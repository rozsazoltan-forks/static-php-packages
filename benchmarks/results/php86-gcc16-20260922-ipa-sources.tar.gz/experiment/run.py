import json,pathlib,subprocess,datetime
root=pathlib.Path('/tmp/php86-ipa-20260922')
new=json.loads((root/'build/builds.json').read_text())
base=json.loads(pathlib.Path('/tmp/php86-flags-20260922/combined-build/builds.json').read_text())
assert set(new['builds'])=={'tailcall-locality','tailcall-pta'}
for key in ['source_commit','source_status','compiler','gcc_parameter_defaults','jobs']:
 assert base[key]==new[key],key
base['builds'].update(new['builds']);base['profiles']+=new['profiles']
(root/'builds.json').write_text(json.dumps(base,indent=2)+'\n')
for cmd in json.loads((root/'commands.json').read_text()):
 print('START',datetime.datetime.now(datetime.timezone.utc).isoformat(),cmd,flush=True)
 subprocess.run(cmd,check=True,cwd='/home/m/packages')
print('COMPLETE',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
