import json,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=pathlib.Path('/tmp/php86-ipa-20260922')
rows=[x for x in json.loads((r/'analysis.json').read_text())['rows'] if x['suite'] not in ['cli','libphp']]
assert len(rows)==10
labels=[]
for x in rows:
 if x['suite']=='phpstan':labels.append('PHPStan on Symfony Demo')
 elif x['suite']=='phpbench':labels.append('Phoronix PHPBench')
 else:labels.append('Symfony '+x['workload']+' ('+('1 core' if '1core' in x['suite'] else '4 cores')+')')
fig,ax=plt.subplots(figsize=(11.5,7.3))
for i,(label,color) in enumerate([('-fipa-reorder-for-locality','#246798'),('-fipa-pta','#b55320')]):
 ys=[n+(i-.5)*.24 for n in range(len(rows))]
 for y,row in zip(ys,rows):
  lo,hi=row['comparisons'][i]['throughput_95ci_percent'];ax.plot([lo,hi],[y,y],color=color,linewidth=1.8);ax.plot([lo,hi],[y,y],'|',color=color,markersize=5)
 ax.plot([x['comparisons'][i]['throughput_change_percent'] for x in rows],ys,'o',color=color,label=label,markersize=5)
ax.set_yticks(range(len(rows)),labels);ax.invert_yaxis();ax.axvline(0,color='#333333',linewidth=1)
ax.set_xlabel('Throughput change versus medium inlining + omit frame pointers (%)')
ax.grid(axis='x',color='#dddddd');ax.set_axisbelow(True);ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='y',length=0)
for y in [1.5,5.5]:ax.axhline(y,color='#dddddd',linewidth=.8)
ax.set_title('PHP 8.6 / GCC 16: two additional optimization flags',loc='left',fontsize=15,pad=50)
ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),frameon=False,fontsize=10)
fig.text(.025,.03,'LTO and OPcache enabled; JIT disabled; no compiler PGO. Ryzen 9 5950X.\nDots: median-ratio estimates. Lines: 95% paired bootstrap intervals; no multiple-comparison correction.',fontsize=9)
fig.subplots_adjust(left=.32,right=.97,top=.80,bottom=.14)
for ext in ['png','svg']:fig.savefig(r/('applications.'+ext),dpi=160,facecolor='white')
