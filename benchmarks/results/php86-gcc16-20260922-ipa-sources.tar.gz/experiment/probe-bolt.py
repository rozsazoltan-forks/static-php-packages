import os,json,pathlib,subprocess,hashlib,time
r=pathlib.Path('/tmp/php86-ipa-20260922'); out=r/'bolt-instrumented';out.mkdir(exist_ok=True)
b=json.loads((r/'bolt-build/builds.json').read_text())['builds']['tailcall-bolt-ready']
bolt=r/'bolt-tool/usr/lib/llvm-21/bin/llvm-bolt'
env=dict(os.environ,LD_LIBRARY_PATH=str(r/'bolt-tool/usr/lib/x86_64-linux-gnu'))
sections=subprocess.check_output(['readelf','-SW',b['libphp']],text=True)
assert '.rela.text' in sections and '.symtab' in sections
cmd=[str(bolt),b['libphp'],'-o',str(out/'libphp.so.0'),'-instrument','-instrumentation-file='+str(r/'bolt-training.fdata'),'-instrumentation-sleep-time=1','-instrumentation-no-counters-clear','-no-threads']
start=time.monotonic()
with (r/'bolt-instrument.log').open('w') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
result={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'sections':sections,'log':(r/'bolt-instrument.log').read_text()}
(r/'bolt-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print('BOLT instrumentation exit',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
(out/'libphp.so').symlink_to('libphp.so.0')
subprocess.run(['/opt/gcc/bin/gcc','/home/m/packages/benchmarks/libphp-cli.c','-L'+str(out),'-Wl,--enable-new-dtags','-Wl,-rpath,'+str(out),'-lphp','-o',str(out/'libphp-cli')],check=True)
opts=['-n','-d','opcache.enable=1','-d','opcache.enable_cli=1','-d','opcache.file_update_protection=0','-d','opcache.jit=disable','-d','opcache.jit_buffer_size=0']
cmd=[str(out/'libphp-cli'),*opts,'-r','echo json_encode([PHP_VERSION,ZEND_VM_KIND,opcache_get_status(false)]);']
p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
result['runtime_smoke']={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(r/'bolt-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['runtime_smoke'],flush=True)
