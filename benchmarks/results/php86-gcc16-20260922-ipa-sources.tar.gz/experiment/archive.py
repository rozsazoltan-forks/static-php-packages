import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

r = Path('/tmp/php86-ipa-20260922')
repo = Path('/home/m/packages/benchmarks')
out = repo / 'results'
prefix = 'php86-gcc16-20260922-ipa-'
names = ['builds', 'analysis', 'cli', 'libphp', 'phpstan', 'phpbench', 'http-1core', 'http-4core',
         'cli-noise-repeat', 'noise-repeat-plan', 'correctness', 'perf-cli', 'perf-libphp',
         'perf-phpstan', 'perf-phpbench', 'perf-http-1core', 'perf-http-4core', 'perf-analysis',
         'bolt-comparison-builds', 'bolt-optimization', 'bolt-training-classic', 'bolt-training-worker',
         'bolt-phpstan', 'bolt-http-1core', 'bolt-perf-phpstan', 'bolt-perf-http-1core', 'bolt-analysis',
         'bolt-sections', 'validation']
sources = {name: r / (name + '.json') for name in names}
sources['bolt-correctness'] = r / 'bolt-validation/correctness.json'
sources['opcache-status-note'] = Path('/tmp/php86-flags-20260922/opcache-status-note.json')
sources['frankenphp-build'] = Path('/tmp/php86-frankenphp-20260922/build-metadata.json')
sources['dependencies'] = Path('/tmp/php86-flags-20260922/dependencies.json')
manifest = {'sources': {}, 'artifacts': {}}
for name, path in sources.items():
    data = path.read_bytes()
    json.loads(data)
    target = out / (prefix + name + '.json.gz')
    target.write_bytes(gzip.compress(data, compresslevel=6, mtime=0))
    manifest['sources'][name] = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    manifest['artifacts'][target.name] = {'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}

bundle = out / (prefix + 'sources.tar.gz')
with tarfile.open(bundle, 'w:gz', compresslevel=6) as tar:
    for pattern in ['*.py', '*commands.json', '*command.json', '*profiles.json', '*profile.json',
                    'source-hashes.json', 'correctness-tests.txt', 'perf-capabilities.txt',
                    'gcc-*.txt', 'bolt-version.txt', 'bolt-packages*.json', 'bolt-*.fdata', 'bolt-*.log',
                    '*driver.log', 'state.json', '*report.md', 'methodology.txt']:
        for path in sorted(r.glob(pattern)):
            name = 'experiment/' + path.name
            if name not in tar.getnames():
                tar.add(path, arcname=name)
    for folder in ['sources', 'bolt-training-runner', 'bolt-validation']:
        for path in sorted((r / folder).iterdir()):
            if path.is_file():
                tar.add(path, arcname='experiment/' + str(path.relative_to(r)))
    tar.add(r / 'bolt-tool/libz3-package.json', arcname='experiment/libz3-package.json')
    tar.add(r / 'bolt-build/builds.json', arcname='experiment/bolt-build/builds.json')
    for path in sorted(repo.iterdir()):
        if path.is_file() and path.suffix in ['.py', '.php', '.c', '.json']:
            tar.add(path, arcname='runners/' + path.name)
    for suffix in ['stdout', 'stderr']:
        tar.add(r / ('bolt-runtime.' + suffix), arcname='experiment/bolt-runtime.' + suffix)
manifest['artifacts'][bundle.name] = {'bytes': bundle.stat().st_size, 'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest()}
for suffix in ['png', 'svg']:
    path = out / (prefix + 'applications.' + suffix)
    shutil.copyfile(r / ('applications.' + suffix), path)
    manifest['artifacts'][path.name] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(out / (prefix + 'manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print('Archived', len(sources), 'JSON documents and', len(manifest['artifacts']), 'artifacts')
