import json,subprocess,pathlib
r=pathlib.Path("/tmp/php86-ipa-20260922")
subprocess.run(json.loads((r/"bolt-build-command.json").read_text()),check=True,cwd="/home/m/packages")
