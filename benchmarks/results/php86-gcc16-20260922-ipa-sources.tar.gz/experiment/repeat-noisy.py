import json,pathlib,subprocess
r=pathlib.Path('/tmp/php86-ipa-20260922');commands=[];selected={}
for sapi,seed in [('cli',8660),('libphp',8661)]:
 d=json.loads((r/(sapi+'.json')).read_text())
 workloads=[e['workload'] for e in d['benchmarks'] if max(s['mad_percent'] for s in e['summary'].values())>3]
 selected[sapi]=workloads
 if workloads:commands.append(['python3','benchmarks/benchmark-matrix.py','/tmp/opencode/packages-vm-lto-src',str(r/'builds.json'),'--output',str(r/(sapi+'-noise-repeat.json')),'--sapi',sapi,'--runs','18','--warmups','2','--target-seconds','.4','--modes','on','--seed',str(seed),'--variants','tailcall-medium-omitfp','tailcall-locality','tailcall-pta','--workloads',*workloads])
(r/'noise-repeat-plan.json').write_text(json.dumps({'criterion':'Repeat every workload where any variant has median absolute deviation >3% of its median runtime; select independently of which flag wins. Keep original samples.','selected':selected,'commands':commands},indent=2)+'\n')
for cmd in commands:
 print('START repeat',cmd,flush=True);subprocess.run(cmd,check=True,cwd='/home/m/packages')
print('NOISE REPEATS COMPLETE',flush=True)
