## Synthetic workloads and noisy-case repeats

The original 16-workload shared-library matrix has descriptive geometric-mean throughput gains of 0.92% for locality and 0.71% for pointer analysis. The initial CLI matrix was noisier. Five CLI workloads exceeded the 3% median-absolute-deviation threshold for at least one variant and were repeated with 18 samples each and a longer calibration target. No shared-library workload crossed that threshold. Both batches remain in the raw archive.

The repeat table shows **elapsed-time changes**; negative is faster. Brackets are 95% paired bootstrap intervals.

| CLI repeat | + locality | + pointer analysis |
|---|---:|---:|
| bench.php | -0.33% [-1.79, +2.53] | +1.19% [-1.13, +3.26] |
| mandel | -0.19% [-0.83, +1.18] | +2.98% [+0.59, +7.87] |
| fibo | +2.61% [+0.96, +5.19] | -0.56% [-2.35, +2.63] |
| hash2 | -0.02% [-1.32, +0.77] | -0.52% [-2.42, +0.99] |
| symfony-yaml | +0.01% [-2.01, +2.27] | +0.99% [-3.04, +2.51] |

Fibonacci does not support the initial 19% CLI regression: the longer repeat is +2.61% for locality and −0.56% for pointer analysis. Shared-library Fibonacci was −1.32% for locality and +1.30% for pointer analysis in the original, steadier matrix. The two SAPIs have different final code layouts. Their differing outcomes are another reason to test the actual shared library used by FrankenPHP.

The main repeatable synthetic gain is exception handling: locality improves the initial CLI timing by about 8% and shared-library timing by about 6%. The CLI counter pass also shows fewer cycles with nearly unchanged instruction count. Pointer analysis retains a small Mandelbrot regression in the longer CLI repeat. These component effects do not establish an application-wide win.

| Original workload | CLI locality | CLI pointer analysis | Shared locality | Shared pointer analysis |
|---|---:|---:|---:|---:|
| bench.php | +2.50% | +2.32% | -0.95% | -0.44% |
| micro_bench.php | -0.59% | -0.06% | +0.32% | -0.31% |
| mandel | -0.72% | +6.50% | +0.84% | +1.24% |
| mandel2 | -0.05% | +0.46% | -0.33% | -0.29% |
| ary3 | +0.37% | +2.83% | +1.17% | +0.13% |
| nestedloop | -0.03% | +0.24% | -0.51% | -1.08% |
| fibo | +18.83% | +1.37% | -1.32% | +1.30% |
| hash2 | +5.63% | -1.88% | -0.00% | -1.47% |
| objects | -0.54% | +0.72% | -1.55% | -0.20% |
| arrays | +0.21% | +2.20% | -0.47% | -0.70% |
| strings-json | -0.22% | -0.19% | -1.89% | -2.46% |
| exceptions | -8.14% | -3.92% | -6.07% | -3.09% |
| generators | -0.14% | -0.75% | -1.01% | -0.45% |
| fibers | +0.52% | -0.32% | -1.27% | -2.00% |
| twig | +5.63% | +0.35% | -1.62% | -0.72% |
| symfony-yaml | -0.70% | -1.03% | +0.27% | -0.69% |

The original table reports elapsed-time changes and includes the noisy observations; use the repeat table above for the five repeated CLI cases.

