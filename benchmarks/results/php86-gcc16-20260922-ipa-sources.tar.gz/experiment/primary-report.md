# PHP 8.6 GCC: locality, pointer analysis, and LLVM BOLT

Measured against the selected **medium inlining + omitted frame pointers** tailcall build. Every PHP run uses OPcache, every candidate uses LTO, and compiler PGO is absent. JIT is disabled.

The two extra GCC flags do not establish a broad application improvement on this machine. Keep the selected baseline unless a representative workload demonstrates a repeatable gain. This is an exploratory comparison on a shared Ryzen 9 5950X host, not a guarantee for other CPUs or PHP builds.

## Application timings

Positive changes below mean higher throughput. PHPStan is expressed as reciprocal analysis time; PHPBench uses its official score; HTTP uses requests/second. Brackets are 95% paired bootstrap intervals.

| Workload | `-fipa-reorder-for-locality` | `-fipa-pta` |
|---|---:|---:|
| PHPStan | +0.40% [-1.64, +2.45] | -1.51% [-3.24, +1.58] |
| PHPBench | -0.58% [-6.47, +6.40] | +3.72% [-4.87, +4.99] |
| classic blog (1 core) | +0.35% [-1.05, +2.41] | +0.98% [-0.97, +3.18] |
| classic post (1 core) | +1.28% [-0.34, +4.28] | +1.01% [-0.60, +2.39] |
| worker blog (1 core) | +0.53% [-1.94, +3.20] | -1.43% [-3.56, +1.75] |
| worker post (1 core) | +2.55% [-0.19, +5.17] | +1.57% [+0.30, +5.22] |
| classic blog (4 cores) | -1.83% [-25.45, +5.95] | +0.94% [-4.75, +4.79] |
| classic post (4 cores) | -1.24% [-11.18, +13.16] | +0.27% [-3.20, +2.43] |
| worker blog (4 cores) | +2.50% [-8.83, +4.97] | +1.11% [-2.71, +5.68] |
| worker post (4 cores) | +1.93% [+0.13, +23.03] | +2.02% [-0.14, +4.30] |

![Application effects and paired intervals](results/php86-gcc16-20260922-ipa-applications.png)

Only two of these 20 intervals exclude zero: pointer analysis on the one-core worker post, and locality on the four-core worker post. Both gains are small, and the latter interval is unusually wide because of slow baseline samples. These intervals are not corrected for multiple comparisons. Neither flag reliably improves PHPStan or PHPBench.

| Metric | Medium + omit FP | + locality | + pointer analysis |
|---|---:|---:|---:|
| PHPStan analysis | 6.4252 s | 6.3998 s | 6.5237 s |
| PHPBench score | 1,217,842.5 | 1,210,718.5 | 1,263,117.5 |
| classic blog (http-1core) | 78.22 req/s | 78.49 req/s | 78.99 req/s |
| classic post (http-1core) | 73.23 req/s | 74.17 req/s | 73.97 req/s |
| worker blog (http-1core) | 191.46 req/s | 192.48 req/s | 188.72 req/s |
| worker post (http-1core) | 208.94 req/s | 214.26 req/s | 212.21 req/s |
| classic blog (http-4core) | 316.51 req/s | 310.71 req/s | 319.49 req/s |
| classic post (http-4core) | 298.38 req/s | 294.67 req/s | 299.19 req/s |
| worker blog (http-4core) | 712.62 req/s | 730.40 req/s | 720.57 req/s |
| worker post (http-4core) | 779.16 req/s | 794.17 req/s | 794.88 req/s |

All 36 timed PHPStan analyses returned zero errors and their 72 parent/worker runtime probes confirmed OPcache enabled and JIT disabled. All 18 official PHPBench runs completed 56 subtests. HTTP samples passed page-content, loaded-library, worker-runtime and OPcache checks.

## Build profile

The baseline is:

```text
-flto -falign-functions=64 -fomit-frame-pointer
--param=inline-unit-growth=100
--param=ipa-cp-unit-growth=100
--param=large-function-growth=500
--param=max-inline-insns-auto=250
--param=max-inline-insns-single=500
```

Each candidate adds exactly one flag, in compilation and in the actual libtool-driven LTO link. The locality option groups call chains; GCC recommends profile feedback for it. Pointer analysis is disabled by default and can increase compilation resource usage. See the [GCC optimization reference](https://gcc.gnu.org/onlinedocs/gcc/Optimize-Options.html#index-fipa-reorder-for-locality).

| Build | libphp `.text` bytes | Observed configure/build time |
|---|---:|---:|
| Medium + omit FP | 16,294,552 | 226.3 s |
| + locality | 16,291,672 | 227.7 s |
| + pointer analysis | 16,347,608 | 217.4 s |

These are single build times, not repeated compile-speed measurements. Neither new candidate caused a large observed build-cost increase here. Each passed 432 PHP correctness tests, with one skipped because `zend_test` is not built; there were no failures or warnings.

