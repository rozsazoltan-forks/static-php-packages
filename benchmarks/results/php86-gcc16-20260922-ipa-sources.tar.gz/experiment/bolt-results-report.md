
Positive changes are throughput gains; brackets are 95% paired bootstrap intervals. “Rewrite vs control” isolates BOLT from its preparation flags.

| Workload | Prepared control vs original | BOLT vs original | Rewrite vs control |
|---|---:|---:|---:|
| PHPStan (shared library) | -1.06% [-1.85, +1.44] | -1.55% [-8.60, -0.04] | -0.50% [-9.46, +1.51] |
| classic blog | +0.83% [-1.19, +7.73] | +0.82% [-3.60, +7.55] | -0.01% [-4.57, +2.54] |
| classic post | +1.24% [-2.01, +5.25] | +2.21% [-2.16, +6.37] | +0.96% [-3.65, +8.04] |
| worker blog | -1.85% [-3.75, +6.74] | -2.58% [-5.98, +5.61] | -0.74% [-5.04, +5.08] |
| worker post | -0.33% [-2.11, +14.99] | +1.76% [-8.43, +22.32] | +2.10% [-6.51, +6.37] |

Absolute medians from this interleaved batch:

| Workload | Original | Prepared control | BOLT |
|---|---:|---:|---:|
| PHPStan (shared library) | 5.915 s | 5.979 s | 6.009 s |
| classic blog | 82.905 req/s | 83.590 req/s | 83.585 req/s |
| classic post | 76.400 req/s | 77.350 req/s | 78.090 req/s |
| worker blog | 178.830 req/s | 175.515 req/s | 174.215 req/s |
| worker post | 196.975 req/s | 196.325 req/s | 200.445 req/s |

The separate hardware-counter pass reports instruction / cycle / branch-miss changes in percent. HTTP counters are per completed request.

| Workload | BOLT vs original: I / C / BM | Rewrite vs control: I / C / BM |
|---|---:|---:|
| PHPStan (shared library) | -0.06 / -2.74 / -0.31 | -0.06 / +3.54 / +1.48 |
| classic blog | +0.11 / -3.29 / -0.52 | +0.06 / -3.86 / -1.92 |
| classic post | +0.09 / -1.54 / +0.13 | +0.17 / -0.49 / -0.87 |
| worker blog | +0.10 / -4.29 / -0.26 | +0.04 / -2.88 / -0.72 |
| worker post | +0.05 / -5.23 / -1.92 | +0.12 / -9.22 / -3.16 |
