import importlib.util,json,math,pathlib,statistics
root=pathlib.Path('/tmp/php86-ipa-20260922')
spec=importlib.util.spec_from_file_location('matrix','/home/m/packages/benchmarks/benchmark-matrix.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
variants=['tailcall-medium-omitfp','tailcall-locality','tailcall-pta']
rows=[]; count=0
for name,nentries,nruns in [('cli',16,12),('libphp',16,12),('phpstan',1,12),('phpbench',1,6),('http-1core',4,9),('http-4core',4,6)]:
 p=root/(name+'.json')
 if not p.exists():continue
 d=json.loads(p.read_text())
 if len(d['benchmarks']) != nentries or any(len(s)!=nruns for e in d['benchmarks'] for s in e['samples'].values()):continue
 for e in d['benchmarks']:
  metric='rps' if name.startswith('http') else 'score' if name=='phpbench' else 'seconds'
  label=(e['mode']+' '+e['workload']) if name.startswith('http') else e.get('workload',name)
  samples={v:[dict(s,seconds=s[metric]) for s in e['samples'][v]] for v in variants}
  count+=sum(map(len,samples.values()))
  comps=[]
  for v in variants[1:]:
   c=m.compare(samples,variants[0],v)
   c['metric_change_percent']=c.pop('elapsed_change_percent')
   if metric=='seconds':
    c['throughput_change_percent']=100*(1/(1+c['metric_change_percent']/100)-1)
    c['throughput_95ci_percent']=[100*(1/(1+x/100)-1) for x in c['paired_bootstrap_95ci_percent'][::-1]]
   else:
    c['throughput_change_percent']=c['metric_change_percent'];c['throughput_95ci_percent']=c['paired_bootstrap_95ci_percent']
   comps.append(c)
  rows.append({'suite':name,'workload':label,'metric':metric,'medians':{v:statistics.median(s['seconds'] for s in samples[v]) for v in variants},'comparisons':comps})
analysis={'measured_samples':count,'rows':rows}
(root/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
for row in rows:
 print(row['suite'],row['workload'],row['medians'])
 for c in row['comparisons']:print(' ',c['candidate'],round(c['throughput_change_percent'],2),[round(x,2) for x in c['throughput_95ci_percent']])
print('SAMPLES',count)
for suite in ['cli','libphp']:
 selected=[r for r in rows if r['suite']==suite]
 if selected:
  print(suite,'geomean throughput',[(v,100*(math.exp(statistics.mean(math.log(r['medians'][variants[0]]/r['medians'][v]) for r in selected))-1)) for v in variants[1:]])
