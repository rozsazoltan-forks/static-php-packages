import json,os,pathlib,subprocess,hashlib,time,shutil
r=pathlib.Path('/tmp/php86-ipa-20260922');meta=json.loads((r/'bolt-build/builds.json').read_text());base=meta['builds']['tailcall-bolt-ready'];lib=r/'bolt-instrumented/libphp.so.0'
meta['builds']['tailcall-bolt-instrumented']=dict(base,libphp=str(lib),libphp_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),libphp_runner=str(lib.parent/'libphp-cli'))
(r/'bolt-training-builds.json').write_text(json.dumps(meta,indent=2)+'\n')
commands=[]
for mode in ['classic','worker']:
 cmd=['python3',str(r/'bolt-training-runner/benchmark-frankenphp.py'),str(r/'bolt-training-builds.json'),'--frankenphp','/tmp/php86-frankenphp-20260922/frankenphp','--demo','/tmp/php86-symfony-demo-20260922','--wrk','/tmp/php-worker-jit/routes-v3/wrk-4.2.0-source/wrk','--duration','2','--warmup','1','--runs','4','--variants','tailcall-bolt-instrumented','--modes',mode,'--output',str(r/('bolt-training-'+mode+'.json'))]
 commands.append(cmd);(r/'bolt-training-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 profile=r/'bolt-training.fdata';before=profile.stat().st_mtime_ns if profile.exists() else 0
 print('START training',mode,flush=True);subprocess.run(cmd,check=True,cwd='/home/m/packages')
 assert profile.exists() and profile.stat().st_mtime_ns>before and profile.stat().st_size>10000
 shutil.copyfile(profile,r/('bolt-'+mode+'.fdata'))
print('BOLT TRAINING COMPLETE',flush=True)
