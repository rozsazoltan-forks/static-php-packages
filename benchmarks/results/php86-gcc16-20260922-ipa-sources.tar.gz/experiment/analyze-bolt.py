import importlib.util
import json
from pathlib import Path
import statistics

r = Path('/tmp/php86-ipa-20260922')
spec = importlib.util.spec_from_file_location('matrix', '/home/m/packages/benchmarks/benchmark-matrix.py')
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
variants = ['tailcall-medium-omitfp', 'tailcall-bolt-ready', 'tailcall-bolt']
events = ['cycles', 'instructions', 'branches', 'branch-misses', 'cache-references', 'cache-misses']
timings, counters = [], []
for name in ['phpstan', 'http-1core']:
    p = r / ('bolt-' + name + '.json')
    if not p.exists():
        continue
    data = json.loads(p.read_text())
    if not data.get('finished_utc'):
        continue
    for entry in data['benchmarks']:
        metric = 'seconds' if name == 'phpstan' else 'rps'
        label = 'PHPStan (shared library)' if name == 'phpstan' else entry['mode'] + ' ' + entry['workload']
        samples = {v: [dict(s, seconds=s[metric]) for s in entry['samples'][v]] for v in variants}
        assert all(len(s) == 6 for s in samples.values())
        comparisons = []
        for before, after in [(variants[0], variants[1]), (variants[0], variants[2]), (variants[1], variants[2])]:
            c = matrix.compare(samples, before, after)
            if metric == 'seconds':
                c['throughput_change_percent'] = 100 * (1 / (1 + c['elapsed_change_percent'] / 100) - 1)
                c['throughput_95ci_percent'] = [100 * (1 / (1 + x / 100) - 1) for x in c['paired_bootstrap_95ci_percent'][::-1]]
            else:
                c['throughput_change_percent'] = c['elapsed_change_percent']
                c['throughput_95ci_percent'] = c['paired_bootstrap_95ci_percent']
            c['metric_change_percent'] = c.pop('elapsed_change_percent')
            comparisons.append(c)
        timings.append({'suite': name, 'workload': label, 'metric': metric,
                        'medians': {v: statistics.median(s['seconds'] for s in samples[v]) for v in variants},
                        'comparisons': comparisons})
    p = r / ('bolt-perf-' + name + '.json')
    if not p.exists():
        continue
    data = json.loads(p.read_text())
    if not data.get('finished_utc'):
        continue
    if name == 'phpstan':
        groups = [('PHPStan (shared library)', {v: [dict(x, denominator=1) for x in data['measurements']
                     if x['variant'] == v and not x['warmup']] for v in variants})]
    else:
        groups = [(e['mode'] + ' ' + e['workload'], {v: [dict(x['perf'], denominator=x['requests'])
                     for x in e['samples'][v]] for v in variants}) for e in data['benchmarks']]
    for label, group in groups:
        assert all(len(samples) == 3 for samples in group.values())
        values = {v: {event: [s['counters'][event]['value'] / s['denominator'] for s in samples]
                      for event in events} for v, samples in group.items()}
        medians = {v: {event: statistics.median(xs) for event, xs in item.items()} for v, item in values.items()}
        changes = {baseline: {candidate: {event: 100 * (medians[candidate][event] / medians[baseline][event] - 1)
                    for event in events} for candidate in variants if candidate != baseline}
                    for baseline in variants[:2]}
        running = min(s['counters'][e]['running_percent'] for samples in group.values() for s in samples for e in events)
        counters.append({'suite': name, 'workload': label, 'medians': medians, 'samples': values,
                         'changes_percent': changes, 'minimum_running_percent': running})
(r / 'bolt-analysis.json').write_text(json.dumps({'timings': timings, 'counters': counters}, indent=2) + '\n')
for row in timings:
    print(row['workload'], row['medians'])
    for c in row['comparisons']:
        print(' ', c['baseline'], 'to', c['candidate'], round(c['throughput_change_percent'], 2),
              [round(x, 2) for x in c['throughput_95ci_percent']])
for row in counters:
    print('COUNTERS', row['workload'], row['minimum_running_percent'])
    for baseline in variants[:2]:
        print(' ', baseline, {k: round(v, 2) for k, v in row['changes_percent'][baseline]['tailcall-bolt'].items()})
