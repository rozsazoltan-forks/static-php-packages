import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

r = Path('/tmp/php86-ipa-20260922')
repo = Path('/home/m/packages')
for name in ['analyze-bolt.py', 'render-bolt-report.py', 'validate.py']:
    subprocess.run(['python3', str(r / name)], check=True)
pieces = ['primary-report.md', 'synthetic-report.md', 'counter-report.md', 'counter-absolute-report.md',
          'bolt-method-report.md', 'bolt-results-report.md', 'bolt-conclusion-report.md',
          'method-report.md', 'artifact-report.md']
report = repo / 'benchmarks/php86-ipa-bolt.md'
report.write_text('\n\n'.join((r / name).read_text().strip() for name in pieces) + '\n')
counts = json.loads((r / 'validation.json').read_text())['counts']
(r / 'state.json').write_text(json.dumps({'status': 'complete',
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'measured_sample_counts': counts, 'report': str(report)}, indent=2) + '\n')
subprocess.run(['python3', str(r / 'archive.py')], check=True)
manifest_path = repo / 'benchmarks/results/php86-gcc16-20260922-ipa-manifest.json'
manifest = json.loads(manifest_path.read_text())
for name, item in manifest['artifacts'].items():
    p = manifest_path.parent / name
    data = p.read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], name
    if name.endswith('.json.gz'):
        json.loads(gzip.decompress(data))
    elif name.endswith('.tar.gz'):
        with tarfile.open(p) as archive:
            assert archive.getnames() and len(archive.getnames()) == len(set(archive.getnames()))
for label, href in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', report.read_text()):
    if not href.startswith(('https://', 'http://', '#')):
        assert (report.parent / href).exists(), (label, href)
subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
print('FINALIZED', report, 'measured samples', sum(counts.values()), 'verified artifacts', len(manifest['artifacts']))
