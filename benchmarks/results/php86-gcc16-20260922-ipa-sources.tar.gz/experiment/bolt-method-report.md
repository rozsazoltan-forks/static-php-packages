## LLVM BOLT experiment

BOLT is technically usable on this GCC/LTO shared PHP library. This experiment uses LLVM BOLT 21.1.8 from the official LLVM Debian packages, extracted locally. No compiler PGO was used; GCC was not rebuilt with profile-use flags. BOLT has its own execution profile, collected from an instrumented copy of the final library.

The three comparison builds are the selected baseline, a **prepared control** adding `-fno-reorder-blocks-and-partition` and link-time `-Wl,--emit-relocs`, and BOLT's rewrite of that exact prepared library. The control matters because its compiler flag changes code layout before BOLT runs. All three remain GCC tailcall/LTO builds with medium inlining and omitted frame pointers. PHPStan runs through the same small shared-library CLI launcher for all three; its absolute times should not be compared directly with the preceding standalone-CLI PHPStan batch.

The host does not expose branch-stack sampling. An instrumented library instead trained on the two Symfony routes in classic and worker modes, on one core with OPcache enabled and JIT disabled. BOLT's periodic profile dump was needed for the shared library; its helper process was cleaned up with the benchmark server's own process group. The retained profile is the accumulated dump from the final server process in each mode, merged across the two modes. Earlier training processes are not included. PHPStan was held out of training.

The rewrite uses:

```text
-reorder-blocks=ext-tsp -reorder-functions=cdsort
-split-functions -split-all-cold -split-eh
-align-functions=64 -align-functions-max-bytes=64
-dyno-stats -update-debug-sections -no-threads
```

The [official BOLT guide](https://github.com/llvm/llvm-project/blob/main/bolt/README.md) documents shared-library support, retained relocations, the GCC block-partitioning constraint and profiling choices. Exact build, instrumentation, merge and rewrite commands, tool/package hashes and profiles are archived with this study.

BOLT found a nonempty profile for 920 of 15,322 functions; 28 profiled functions could not be optimized. It reordered blocks in 731 functions. The log reports a 100% call-graph flow conservation gap, even though its CFG discontinuity and CFG flow gaps are zero. This profile-quality limitation is retained in the evidence rather than presented as an ideal profile. BOLT also warned about 409 unanalyzed relocations, a `make_fcontext` frame-description conflict, a cold function from a static dependency, and unsupported DWARF encodings/forms. Passing tests do not establish complete native unwind/debug-info fidelity.

The prepared control and rewritten library each passed 432 correctness tests with one `zend_test`-dependent skip and no failures or warnings from the PHP test harness. All measured PHPStan analyses and HTTP response/runtime checks passed. This is an exploratory local result, not a production validation of arbitrary extensions or native debugging tools.

The timed BOLT comparison uses six interleaved samples per variant for PHPStan and each of the four one-core HTTP cases. Hardware counters use a separate three-sample pass. Keeping perf out of the timing pass avoids using its visibly perturbed HTTP throughput as the speed estimate. Four-core BOLT and retraining on additional applications were not measured.
