
The following absolute medians give the counter changes scale. IPC and miss rates here are ratios of the displayed counter medians.

| Workload / build | Instructions | Cycles | IPC | Branch-miss rate | Generic cache misses |
|---|---:|---:|---:|---:|---:|
| PHPStan: baseline | 34.437B | 20.484B | 1.681 | 2.062% | 299.591M |
| PHPStan: locality | 34.393B | 20.371B | 1.688 | 2.020% | 295.266M |
| PHPStan: pointer analysis | 34.448B | 20.145B | 1.710 | 2.047% | 297.014M |
| PHPBench: baseline | 233.671B | 62.620B | 3.732 | 0.080% | 4.487M |
| PHPBench: locality | 233.491B | 63.699B | 3.666 | 0.083% | 3.924M |
| PHPBench: pointer analysis | 233.744B | 62.660B | 3.730 | 0.087% | 4.066M |
| Worker blog / request: baseline | 22.892M | 23.837M | 0.960 | 4.892% | 0.662M |
| Worker blog / request: locality | 22.880M | 26.247M | 0.872 | 5.003% | 0.681M |
| Worker blog / request: pointer analysis | 22.908M | 22.517M | 1.017 | 4.839% | 0.665M |

CLI Mandelbrot’s branch-miss rate changes from 0.128% at baseline to 1.200% with pointer analysis. This is consistent with its small repeated timing regression, but these observations alone do not isolate why branch prediction changed.
