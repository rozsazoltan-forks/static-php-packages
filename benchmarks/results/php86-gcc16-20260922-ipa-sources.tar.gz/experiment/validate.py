import ast
import hashlib
import json
from pathlib import Path
import re

r = Path('/tmp/php86-ipa-20260922')
repo = Path('/home/m/packages/benchmarks')
counts = {}
runtime_probes = 0

def runtime(info):
    global runtime_probes
    assert info['opcache']['opcache_enabled']
    assert not info['opcache'].get('jit', {}).get('on', False)
    assert info['vm'] == 'ZEND_VM_KIND_TAILCALL'
    runtime_probes += 1

specifications = [('cli', 16, 12), ('libphp', 16, 12), ('phpstan', 1, 12), ('phpbench', 1, 6),
                  ('http-1core', 4, 9), ('http-4core', 4, 6), ('cli-noise-repeat', 5, 18),
                  ('bolt-phpstan', 1, 6), ('bolt-http-1core', 4, 6),
                  ('perf-http-1core', 4, 3), ('perf-http-4core', 4, 3), ('bolt-perf-http-1core', 4, 3)]
for name, entries, runs in specifications:
    data = json.loads((r / (name + '.json')).read_text())
    assert data['finished_utc'] and len(data['benchmarks']) == entries, name
    for info in data.get('runtime', {}).values():
        runtime(info)
    n = 0
    for entry in data['benchmarks']:
        assert len(entry['samples']) == 3, name
        for variant, samples in entry['samples'].items():
            assert len(samples) == runs, (name, variant)
            for s in samples:
                assert s['seconds'] > 0
                assert s.get('exit_code', 0) == 0
                if 'runtime' in s:
                    runtime(s['runtime'])
                if 'process_runtime' in s:
                    assert len({x['pid'] for x in s['process_runtime']}) == 2
                    assert all(x['opcache_enabled'] and not x['jit_on'] for x in s['process_runtime'])
                    assert s['analysis']['totals']['errors'] == s['analysis']['totals']['file_errors'] == 0
                if 'per_test_seconds' in s:
                    assert len(s['per_test_seconds']) == 56
                if 'perf' in s:
                    assert all(s['perf']['counters'][e]['value'] > 0 and
                               s['perf']['counters'][e]['running_percent'] == 100
                               for e in ['cycles', 'instructions', 'branches', 'branch-misses', 'cache-references', 'cache-misses'])
            n += len(samples)
    counts[name] = n
for name, expected in [('perf-cli', 144), ('perf-libphp', 144), ('perf-phpstan', 9),
                       ('perf-phpbench', 9), ('bolt-perf-phpstan', 9)]:
    data = json.loads((r / (name + '.json')).read_text())
    assert data['finished_utc']
    measured = [s for s in data['measurements'] if not s['warmup']]
    assert len(measured) == expected
    for s in data['measurements']:
        assert s['exit_code'] == 0
        assert all(s['counters'][e]['value'] > 0 and s['counters'][e]['running_percent'] == 100
                   for e in ['cycles', 'instructions', 'branches', 'branch-misses', 'cache-references', 'cache-misses'])
        if 'runtime' in s:
            assert len(s['runtime']) == 2 and all(x['opcache_enabled'] and not x['jit_on'] for x in s['runtime'])
    counts[name] = len(measured)
tests = {}
for path in [r / 'correctness.json', r / 'bolt-validation/correctness.json']:
    data = json.loads(path.read_text())
    for run in data['runs']:
        assert run['exit_code'] == 0
        assert re.search(r'Tests failed\s*:\s*0\b', run['log'])
        assert re.search(r'Tests warned\s*:\s*0\b', run['log'])
        assert re.search(r'Tests passed\s*:\s*432\b', run['log'])
        tests[run['variant']] = {'passed': 432, 'skipped': 1, 'failed': 0}
hashes = {}
for path in [*repo.glob('*.py'), *r.glob('*.py')]:
    ast.parse(path.read_text(), filename=str(path))
    hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
result = {'counts': counts, 'total_measured_samples': sum(counts.values()), 'runtime_identity_probes_checked': runtime_probes,
          'correctness': tests, 'python_source_sha256': hashes, 'python_syntax': 'pass'}
(r / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'python_source_sha256'}, indent=2))
