import json
from pathlib import Path

r = Path('/tmp/php86-ipa-20260922')
data = json.loads((r / 'bolt-analysis.json').read_text())
assert len(data['timings']) == len(data['counters']) == 5
variants = ['tailcall-medium-omitfp', 'tailcall-bolt-ready', 'tailcall-bolt']

def effect(c):
    lo, hi = c['throughput_95ci_percent']
    return f"{c['throughput_change_percent']:+.2f}% [{lo:+.2f}, {hi:+.2f}]"

lines = ['\nPositive changes are throughput gains; brackets are 95% paired bootstrap intervals. “Rewrite vs control” isolates BOLT from its preparation flags.\n',
         '| Workload | Prepared control vs original | BOLT vs original | Rewrite vs control |',
         '|---|---:|---:|---:|']
for row in data['timings']:
    lines.append('| ' + row['workload'] + ' | ' + ' | '.join(effect(c) for c in row['comparisons']) + ' |')
lines += ['\nAbsolute medians from this interleaved batch:\n',
          '| Workload | Original | Prepared control | BOLT |', '|---|---:|---:|---:|']
for row in data['timings']:
    unit = ' s' if row['metric'] == 'seconds' else ' req/s'
    lines.append('| ' + row['workload'] + ' | ' + ' | '.join(f"{row['medians'][v]:.3f}{unit}" for v in variants) + ' |')
lines += ['\nThe separate hardware-counter pass reports instruction / cycle / branch-miss changes in percent. HTTP counters are per completed request.\n',
          '| Workload | BOLT vs original: I / C / BM | Rewrite vs control: I / C / BM |',
          '|---|---:|---:|']
for row in data['counters']:
    cols = []
    for baseline in variants[:2]:
        changes = row['changes_percent'][baseline]['tailcall-bolt']
        cols.append(' / '.join(f'{changes[event]:+.2f}' for event in ['instructions', 'cycles', 'branch-misses']))
    lines.append('| ' + row['workload'] + ' | ' + ' | '.join(cols) + ' |')
(r / 'bolt-results-report.md').write_text('\n'.join(lines) + '\n')
