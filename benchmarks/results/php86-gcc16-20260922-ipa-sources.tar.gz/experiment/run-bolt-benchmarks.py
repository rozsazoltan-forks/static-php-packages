import json,pathlib,subprocess
r=pathlib.Path("/tmp/php86-ipa-20260922")
for cmd in json.loads((r/"bolt-benchmark-commands.json").read_text()):
 print("START",cmd,flush=True)
 subprocess.run(cmd,check=True,cwd="/home/m/packages")
print("BOLT BENCHMARKS COMPLETE",flush=True)
