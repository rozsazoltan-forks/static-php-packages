import json,os,subprocess
from pathlib import Path
root=Path('/tmp/php86-ipa-20260922/bolt-validation')
source=Path('/tmp/opencode/packages-vm-lto-src')
variants=['tailcall-bolt-ready','tailcall-bolt']
builds=json.loads((root.parent/'bolt-comparison-builds.json').read_text())['builds']
ini = root / 'correctness.ini'
ini.write_text('opcache.enable=1\nopcache.enable_cli=1\nopcache.file_update_protection=0\n'
               'opcache.jit=disable\nopcache.jit_buffer_size=0\n')
env = dict(os.environ, PHPRC=str(ini), PHP_INI_SCAN_DIR='', NO_INTERACTION='1',
           REPORT_EXIT_STATUS='1', SKIP_ONLINE_TESTS='1', XDEBUG_MODE='off', LC_ALL='C')
tests = [Path(p) for p in (root / 'correctness-tests.txt').read_text().splitlines()]
assert len(tests) == 433
assert all('opcache.' not in p.read_text() for p in tests)
results = []
for variant in variants:
    log = root / f'correctness-{variant}.log'
    command = [builds[variant]['binary'], '-c', str(ini), str(source / 'run-tests.php'),
               '-p', builds[variant]['libphp_runner'], '-c', str(ini), '-j4', '-q', '--offline',
               '-d', 'opcache.enable=1', '-d', 'opcache.enable_cli=1',
               '-d', 'opcache.file_update_protection=0', '-d', 'opcache.jit=disable',
               '-d', 'opcache.jit_buffer_size=0', '-r', str(root / 'correctness-tests.txt'),
               '-W', str(root / f'correctness-{variant}.results'),
               '-w', str(root / f'correctness-{variant}.failed')]
    print('START correctness', variant, flush=True)
    with log.open('w') as handle:
        run = subprocess.run(command, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT)
    results.append({'variant': variant, 'command': command, 'exit_code': run.returncode,
                    'log': log.read_text(), 'results': (root / f'correctness-{variant}.results').read_text()})
    (root / 'correctness.json').write_text(json.dumps({'ini': ini.read_text(), 'environment': {
        k: env[k] for k in ['PHPRC', 'PHP_INI_SCAN_DIR', 'NO_INTERACTION', 'REPORT_EXIT_STATUS',
                           'SKIP_ONLINE_TESTS', 'XDEBUG_MODE', 'LC_ALL']}, 'tests': [str(p) for p in tests],
        'runs': results}, indent=2) + '\n')
    print(variant, 'exit', run.returncode, log.read_text()[-3500:], flush=True)
    if run.returncode:
        raise SystemExit(run.returncode)
print('CORRECTNESS COMPLETE', flush=True)
