import json,pathlib,statistics
r=pathlib.Path('/tmp/php86-ipa-20260922');variants=['tailcall-medium-omitfp','tailcall-locality','tailcall-pta'];events=['cycles','instructions','branches','branch-misses','cache-references','cache-misses'];rows=[]
for name in ['cli','libphp','phpstan','phpbench','http-1core','http-4core']:
 p=r/('perf-'+name+'.json')
 if not p.exists():continue
 d=json.loads(p.read_text())
 if not d.get('finished_utc'):continue
 if name.startswith('http'):
  groups=[(e['mode']+' '+e['workload'],{v:[{'counters':x['perf']['counters'],'denominator':x['requests']} for x in e['samples'][v]] for v in variants}) for e in d['benchmarks']]
 else:
  workloads=list(dict.fromkeys(x['workload'] for x in d['measurements']))
  groups=[(w,{v:[dict(x,denominator=1) for x in d['measurements'] if x['workload']==w and x['variant']==v and not x['warmup']] for v in variants}) for w in workloads]
 for workload,group in groups:
  medians={v:{event:statistics.median(s['counters'][event]['value']/s['denominator'] for s in samples) for event in events} for v,samples in group.items()}
  raw_samples={v:{event:[s['counters'][event]['value']/s['denominator'] for s in samples] for event in events} for v,samples in group.items()}
  changes={v:{event:100*(medians[v][event]/medians[variants[0]][event]-1) for event in events} for v in variants[1:]}
  running=min(s['counters'][e]['running_percent'] for samples in group.values() for s in samples for e in events)
  rows.append({'suite':name,'workload':workload,'unit':'per request' if name.startswith('http') else 'per process invocation','minimum_running_percent':running,'medians':medians,'changes_percent':changes,'samples':raw_samples})
(r/'perf-analysis.json').write_text(json.dumps({'rows':rows},indent=2)+'\n')
for row in rows:
 if row['suite'] in ['cli','libphp'] and row['workload'] not in ['fibo','exceptions','mandel']:continue
 print(row['suite'],row['workload'],'running',row['minimum_running_percent'])
 for v in variants[1:]:print(v,{k:round(x,2) for k,x in row['changes_percent'][v].items()})
