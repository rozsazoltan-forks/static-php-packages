## Hardware counters

The separate `perf stat` pass contains three measured samples per variant per case, interleaved after a discarded warmup. It covers all 16 CLI workloads, all 16 shared-library workloads, PHPStan, the exact PHPBench payload (`-i 2000000`), and both Symfony routes/modes at one and four cores. There are 378 measured counter samples. Microbenchmark counters cover the whole process, including startup, setup and the four internal warmup calls; their scope is wider than the internal PHP timer. The PHPBench counter pass excludes the PTS controller. PHPStan includes its inherited analysis worker. HTTP counters attach only to the benchmark server PID, including its threads, and use an acknowledged enable/disable window around wrk. Counts are divided by completed requests.

All six hardware events reported 100% running time: cycles, instructions, branches, branch misses, generic cache references and generic cache misses. L1 instruction-cache and instruction-TLB miss probes returned “not counted” and were excluded. Generic cache events must not be interpreted as specific instruction-cache events. These are the guest-visible counters of a WSL2 virtual PMU.

The HTTP counter batches are slower and substantially more variable than the separate timing batches. The counter pass provides execution counts; the separate unprofiled batch supplies the headline throughput estimate. Some four-core cycle medians are dominated by slow samples; their large changes below are retained, not treated as reliable flag effects. Each cell gives **instruction change / cycle change / branch-miss change**, in percent, relative to medium + omit FP. Negative means fewer events.

| Counter workload | + locality: I / C / BM | + pointer analysis: I / C / BM |
|---|---:|---:|
| cli: mandel | -0.00 / +10.75 / +5.98 | +0.00 / +4.87 / +838.41 |
| cli: fibo | -0.00 / +7.52 / -5.08 | +0.00 / +8.04 / -5.84 |
| cli: exceptions | -0.08 / -9.41 / -0.42 | +0.34 / -2.23 / +1.75 |
| libphp: mandel | -0.00 / -0.27 / +0.27 | +0.00 / -0.32 / +0.68 |
| libphp: fibo | -0.00 / -4.33 / -0.85 | +0.00 / +1.93 / -1.24 |
| libphp: exceptions | -0.34 / -1.71 / +1.22 | +0.08 / -6.29 / -2.19 |
| phpstan: phpstan | -0.13 / -0.55 / -2.12 | +0.03 / -1.65 / -0.75 |
| phpbench: phpbench | -0.08 / +1.72 / +4.43 | +0.03 / +0.06 / +9.47 |
| http-1core: classic blog | +0.02 / -1.64 / -0.92 | +0.17 / -3.58 / +0.66 |
| http-1core: classic post | -0.30 / -7.95 / -1.40 | +0.01 / -7.45 / -0.53 |
| http-1core: worker blog | -0.05 / +10.11 / +2.28 | +0.07 / -5.54 / -1.06 |
| http-1core: worker post | -0.10 / +30.08 / +5.89 | +0.07 / -4.92 / -0.17 |
| http-4core: classic blog | +0.49 / +47.54 / +13.46 | +0.03 / -14.19 / -2.91 |
| http-4core: classic post | +1.21 / +109.04 / +21.56 | -0.42 / -1.39 / +1.12 |
| http-4core: worker blog | -0.16 / -11.97 / -5.62 | +0.08 / -10.74 / -3.49 |
| http-4core: worker post | -0.31 / -14.56 / -2.70 | +0.03 / -11.65 / -0.97 |

The useful broad observation is that neither flag materially reduces PHP instruction work: PHPStan and PHPBench instruction changes are within about 0.13%, and the one-core HTTP changes within about 0.3%. The CLI exception case shows a larger cycle reduction for locality, consistent with its timing improvement, despite almost unchanged instructions. This does not identify a specific cache or branch mechanism.

The user-filtered software context-switch event reported zeros even when `/proc` showed switches, so those zeros are not used as evidence of an idle host. HTTP data additionally stores per-thread `/proc` context-switch snapshots and deltas. CLI/application data stores `getrusage` context-switch and CPU-time deltas for the process tree, including the perf launcher. Raw counters, event running times, individual observations and all derived ratios are retained.

