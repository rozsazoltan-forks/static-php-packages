import os,json,pathlib,subprocess,hashlib,time
r=pathlib.Path('/tmp/php86-ipa-20260922');tool=r/'bolt-tool/usr/lib/llvm-21/bin';env=dict(os.environ,LD_LIBRARY_PATH=str(r/'bolt-tool/usr/lib/x86_64-linux-gnu'))
base=json.loads((r/'bolt-build/builds.json').read_text());b=base['builds']['tailcall-bolt-ready'];out=r/'bolt-optimized';out.mkdir(exist_ok=False)
merge=[str(tool/'merge-fdata'),str(r/'bolt-classic.fdata'),str(r/'bolt-worker.fdata')]
with (r/'bolt-merged.fdata').open('w') as f:subprocess.run(merge,env=env,stdout=f,check=True)
cmd=[str(tool/'llvm-bolt'),b['libphp'],'-o',str(out/'libphp.so.0'),'-data='+str(r/'bolt-merged.fdata'),'-reorder-blocks=ext-tsp','-reorder-functions=cdsort','-split-functions','-split-all-cold','-split-eh','-align-functions=64','-align-functions-max-bytes=64','-dyno-stats','-update-debug-sections','-no-threads']
t=time.monotonic()
with (r/'bolt-optimize.log').open('w') as log:run=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
meta={'merge_command':merge,'command':cmd,'seconds':time.monotonic()-t,'exit_code':run.returncode,'log':(r/'bolt-optimize.log').read_text()}
(r/'bolt-optimization.json').write_text(json.dumps(meta,indent=2)+'\n')
if run.returncode:raise SystemExit(run.returncode)
(out/'libphp.so').symlink_to('libphp.so.0')
subprocess.run(['/opt/gcc/bin/gcc','/home/m/packages/benchmarks/libphp-cli.c','-L'+str(out),'-Wl,--enable-new-dtags','-Wl,-rpath,'+str(out),'-lphp','-o',str(out/'libphp-cli')],check=True)
base['builds']['tailcall-bolt']=dict(b,libphp=str(out/'libphp.so.0'),libphp_sha256=hashlib.sha256((out/'libphp.so.0').read_bytes()).hexdigest(),libphp_runner=str(out/'libphp-cli'),post_link=meta)
medium=json.loads((r/'builds.json').read_text())['builds']['tailcall-medium-omitfp'];base['builds']['tailcall-medium-omitfp']=medium
for v in base['builds']:
    item=base['builds'][v]
    item['original_cli_sha256']=item['sha256']
    item['binary']=item['libphp_runner']
    item['sha256']=hashlib.sha256(pathlib.Path(item['binary']).read_bytes()).hexdigest()
base['comparison_note']='Every CLI application uses the libphp CLI launcher; only libphp is optimized by BOLT.'
(r/'bolt-comparison-builds.json').write_text(json.dumps(base,indent=2)+'\n')
print('BOLT OPTIMIZATION COMPLETE',flush=True)
