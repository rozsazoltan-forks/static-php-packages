import datetime
import importlib.util
import json
import os
from pathlib import Path
import random
import statistics
import subprocess

root = Path('/tmp/php86-flags-20260922')
repo = Path('/home/m/packages/benchmarks')
base = json.loads((root / 'final-cli.json').read_text())
entry = next(e for e in base['benchmarks'] if e['workload'] == 'fibo')
variants = base['arguments']['variants']
scratch = (root / 'final-cli.json').with_suffix('.work')
output = root / 'final-fibo-perf-cli-paired.json'
spec = importlib.util.spec_from_file_location('matrix', repo / 'benchmark-matrix.py')
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
result = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'benchmark': str(root / 'final-cli.json'), 'runs': 8, 'scale': 10, 'seed': 8636,
          'note': 'Eight interleaved blocks; counters include setup and four internal warmups. No samples removed.',
          'orders': [], 'samples': {v: [] for v in variants}}
rng = random.Random(8636)
for block in range(8):
    if block % len(variants) == 0:
        order = list(variants)
        rng.shuffle(order)
    else:
        order = order[1:] + order[:1]
    result['orders'].append(list(order))
    for variant in order:
        binary = base['builds']['builds'][variant]['binary']
        statfile = root / f'paired-fibo-{block}-{variant}.csv'
        command = ['perf', 'stat', '-x,', '-o', str(statfile), '-e',
                   'cycles:u,instructions:u,branches:u,branch-misses:u,cache-misses:u', '--',
                   'taskset', '-c', str(base['arguments']['cpu']), binary, *entry['options'],
                   str(repo / 'workloads.php'), 'fibo', str(entry['iterations'] * 10),
                   str(scratch / 'functions.php'), base['arguments']['autoload']]
        run = subprocess.run(command, check=True, capture_output=True, text=True,
                             env=dict(os.environ, VM_BENCH_CACHE=str(scratch / 'twig-cache')))
        sample = json.loads(run.stdout)
        assert sample['cached'] is True and sample['checksum'] == entry['samples'][variant][0]['checksum']
        counters = {}
        for line in statfile.read_text().splitlines():
            fields = line.split(',')
            if len(fields) >= 3 and fields[2].endswith(':u'):
                assert not fields[0].startswith('<')
                counters[fields[2]] = float(fields[0])
        result['samples'][variant].append({'block': block, 'command': command,
            'stat': statfile.read_text(), 'stdout': sample, 'counters': counters, 'stderr': run.stderr})
        output.write_text(json.dumps(result, indent=2) + '\n')
        print(block, variant, round(sample['seconds'], 3), counters, flush=True)
result['measurements'] = [{'variant': v, 'workload': 'fibo',
    'counters': {event: statistics.median(s['counters'][event] for s in runs)
                 for event in runs[0]['counters']}} for v, runs in result['samples'].items()]
result['comparisons'] = {}
for event in result['measurements'][0]['counters']:
    samples = {v: [{'seconds': s['counters'][event]} for s in runs] for v, runs in result['samples'].items()}
    result['comparisons'][event] = [matrix.compare(samples, variants[0], v) for v in variants[1:]]
result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
output.write_text(json.dumps(result, indent=2) + '\n')
print('PAIRED PERF COMPLETE', flush=True)
