import importlib.util
import json
from pathlib import Path
import statistics

root = Path('/tmp/php86-flags-20260922')
spec = importlib.util.spec_from_file_location('matrix', '/home/m/packages/benchmarks/benchmark-matrix.py')
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
variants = ['hybrid-tuned', 'tailcall-tuned', 'tailcall-omitfp', 'tailcall-medium-omitfp']
short = {'hybrid-tuned': 'Hybrid', 'tailcall-tuned': 'Tailcall',
         'tailcall-omitfp': 'Tailcall, omit FP', 'tailcall-medium-omitfp': 'Medium, omit FP'}
analysis = {}
tables = []

def effect(c):
    value = c.get('elapsed_change_percent', c.get('throughput_change_percent'))
    lo, hi = c['paired_bootstrap_95ci_percent']
    return f'{value:+.1f}% [{lo:+.1f}, {hi:+.1f}]'

for name in ['final-cli', 'final-libphp', 'final-phpstan', 'final-phpbench',
             'final-http-1core', 'final-http-4core']:
    data = json.loads((root / f'{name}.json').read_text())
    assert data.get('finished_utc')
    entries = []
    tables.extend([f'### {name}', ''])
    if name.startswith('final-http'):
        tables += ['| Mode / page | Hybrid req/s | Tailcall req/s | Omit FP req/s | Medium + omit FP req/s |',
                   '| --- | ---: | ---: | ---: | ---: |']
    else:
        tables += ['| Workload | Hybrid ms | Tailcall ms | Omit FP ms | Medium + omit FP ms |',
                   '| --- | ---: | ---: | ---: | ---: |']
    for entry in data['benchmarks']:
        assert all(len(samples) == data['arguments']['runs'] for samples in entry['samples'].values())
        label = entry.get('workload', data['arguments'].get('benchmark', name))
        if name.startswith('final-http'):
            label = entry['mode'] + ' / ' + label
        else:
            assert entry['mode'] == 'on'
        samples = entry['samples']
        for variant, runs in samples.items():
            for sample in runs:
                if 'cached' in sample:
                    assert sample['cached'] is True
                if 'process_runtime' in sample:
                    assert len(sample['process_runtime']) >= 2
                    assert all(p['opcache_enabled'] and not p['jit_on'] for p in sample['process_runtime'])
                if 'per_test_seconds' in sample:
                    assert len(sample['per_test_seconds']) == 56
                if name.startswith('final-http'):
                    opcache = sample['runtime']['opcache']
                    assert opcache['opcache_enabled'] and not opcache['jit']['on']
                    assert not any(opcache[k] for k in ['cache_full', 'restart_pending', 'restart_in_progress'])
                    stats = opcache['opcache_statistics']
                    assert stats['num_cached_scripts'] >= 100
                    assert not any(stats[k] for k in ['oom_restarts', 'hash_restarts', 'manual_restarts'])
                    assert 'BENCH_INVALID 0' in sample['stdout']
                    assert 'Socket errors:' not in sample['stdout']
                    if entry['mode'] == 'worker':
                        assert len(sample['workers']) == data['arguments']['php_threads']
                        assert all(w['opcache']['opcache_enabled'] and not w['opcache']['jit']['on']
                                   for w in sample['workers'])
        unit = entry.get('iterations', 1)
        medians = {v: statistics.median(s['seconds'] for s in samples[v]) / unit for v in variants}
        row = {'label': label, 'median_seconds_per_unit': medians,
               'hybrid_comparisons': [matrix.compare(samples, variants[0], v) for v in variants[1:]],
               'tailcall_comparisons': [matrix.compare(samples, variants[1], v) for v in variants[2:]]}
        if name.startswith('final-http'):
            rps = {v: [dict(s, seconds=s['rps']) for s in samples[v]] for v in variants}
            row['rps'] = {v: statistics.median(s['rps'] for s in samples[v]) for v in variants}
            row['rps_hybrid_comparisons'] = [matrix.compare(rps, variants[0], v) for v in variants[1:]]
            row['rps_tailcall_comparisons'] = [matrix.compare(rps, variants[1], v) for v in variants[2:]]
            row['p50_ms'] = {v: statistics.median(s['p50_ms'] for s in samples[v]) for v in variants}
            row['p99_ms'] = {v: statistics.median(s['p99_ms'] for s in samples[v]) for v in variants}
            row['server_cpu_ms_per_request'] = {v: 1000 * statistics.median(s['cpu_seconds'] for s in samples[v])
                                              for v in variants}
            values = row['rps']
        else:
            values = {v: t * 1000 for v, t in medians.items()}
        if name == 'final-phpbench':
            score = {v: [dict(s, seconds=s['score']) for s in samples[v]] for v in variants}
            row['scores'] = entry['median_scores']
            row['score_hybrid_comparisons'] = [matrix.compare(score, variants[0], v) for v in variants[1:]]
            row['score_tailcall_comparisons'] = [matrix.compare(score, variants[1], v) for v in variants[2:]]
        tables.append('| ' + label + ' | ' + ' | '.join(f'{values[v]:.3f}' for v in variants) + ' |')
        entries.append(row)
    analysis[name] = entries
    tables += ['', '| Workload | Tailcall vs hybrid | Omit FP vs hybrid | Medium + omit FP vs hybrid | Omit FP vs tailcall | Medium + omit FP vs tailcall |',
               '| --- | ---: | ---: | ---: | ---: | ---: |']
    for row in entries:
        prefix = 'rps_' if name.startswith('final-http') else ''
        comparisons = row[prefix + 'hybrid_comparisons'] + row[prefix + 'tailcall_comparisons']
        tables.append('| ' + row['label'] + ' | ' + ' | '.join(effect(c) for c in comparisons) + ' |')
    tables.append('')
(root / 'analysis.json').write_text(json.dumps(analysis, indent=2) + '\n')
(root / 'tables.md').write_text('\n'.join(tables) + '\n')
print('Validated and summarized all six final matrices.')
