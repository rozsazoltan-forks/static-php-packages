import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

root = Path('/tmp/php86-flags-20260922')
repo = Path('/home/m/packages/benchmarks')
out = repo / 'results'
prefix = 'php86-gcc16-20260922-flags-'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

commands = {'final': json.loads((root / 'final-commands.json').read_text()),
            'diagnostics': json.loads((root / 'diagnostic-commands.json').read_text()),
            'paired_perf': ['python3', str(root / 'perf-paired.py')],
            'screen_controller': (root / 'run-screen.py').read_text(),
            'correctness_controller': (root / 'run-diagnostics.py').read_text()}
(root / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
names = ['screen-cli', 'screen-phpstan', 'screen-http', 'final-cli', 'final-libphp',
         'final-phpstan', 'final-phpbench', 'final-http-1core', 'final-http-4core',
         'analysis', 'phpbench-subtests', 'final-fibo-perf-cli', 'final-fibo-perf-libphp',
         'final-fibo-perf-cli-paired', 'align32-mandel-perf', 'correctness',
         'opcache-status-note', 'commands', 'dependencies', 'build-sections']
paths = {name: root / f'{name}.json' for name in names}
paths['builds'] = root / 'final-builds.json'
paths['frankenphp-build'] = Path('/tmp/php86-frankenphp-20260922/build-metadata.json')
manifest = {}
for name, path in paths.items():
    content = path.read_bytes()
    json.loads(content)
    target = out / f'{prefix}{name}.json.gz'
    target.write_bytes(gzip.compress(content, compresslevel=9, mtime=0))
    assert gzip.decompress(target.read_bytes()) == content
    manifest[target.name] = {'sha256': sha(target), 'uncompressed_sha256': hashlib.sha256(content).hexdigest()}

sources = {p.name: p for p in repo.iterdir() if p.suffix in ['.py', '.php', '.c', '.json']}
for name in ['screen-phpstan-runner.py', 'final-phpstan-runner.py', 'measured-workloads.php',
             'run-screen.py', 'run-final.py', 'run-diagnostics.py', 'perf-paired.py',
             'analyze-results.py', 'write-report.py', 'archive-results.py', 'report-method.md',
             'correctness-tests.txt', 'correctness.ini', 'opcache-diagnostic.txt']:
    sources['study/' + name] = root / name
for p in root.glob('*.asm'):
    sources['assembly/' + p.name] = p
sources['upstream/bench.php'] = Path('/tmp/opencode/packages-vm-lto-src/Zend/bench.php')
sources['upstream/micro_bench.php'] = Path('/tmp/opencode/packages-vm-lto-src/Zend/micro_bench.php')
sources['study/functions.php'] = root / 'final-cli.work/functions.php'
source_hashes = {name: sha(path) for name, path in sources.items()}
for name in ['screen-cli', 'final-cli', 'final-libphp']:
    data = json.loads((root / f'{name}.json').read_text())
    for filename, expected in data['sha256'].items():
        actual = root / 'measured-workloads.php' if filename.endswith('/workloads.php') else Path(filename)
        assert sha(actual) == expected, filename
for name, filename in [('screen-phpstan', 'screen-phpstan-runner.py'),
                       ('final-phpstan', 'final-phpstan-runner.py')]:
    assert json.loads((root / f'{name}.json').read_text())['runner_sha256'] == sha(root / filename)
for name in ['screen-http', 'final-http-1core', 'final-http-4core']:
    assert json.loads((root / f'{name}.json').read_text())['runner_sha256'] == sha(repo / 'benchmark-frankenphp.py')
assert json.loads((root / 'final-phpbench.json').read_text())['runner_sha256'] == sha(repo / 'benchmark-applications.py')
with tarfile.open(out / f'{prefix}sources.tar.gz', 'w:gz') as archive:
    for name, path in sorted(sources.items()):
        archive.add(path, arcname=name, recursive=False)
    content = (json.dumps(source_hashes, indent=2) + '\n').encode()
    info = tarfile.TarInfo('SHA256.json')
    info.size = len(content)
    archive.addfile(info, io.BytesIO(content))
with tarfile.open(out / f'{prefix}sources.tar.gz', 'r:gz') as archive:
    for name, expected in source_hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected

validation = {'source_hashes_verified': True, 'gzip_roundtrips_verified': True,
              'measured_samples': 0, 'http_requests': 0, 'http_server_logs': 0,
              'http_body_hashes': {}, 'correctness_runs': [], 'artifacts': manifest}
for name in ['screen-cli', 'screen-phpstan', 'screen-http', 'final-cli', 'final-libphp',
             'final-phpstan', 'final-phpbench', 'final-http-1core', 'final-http-4core']:
    data = json.loads((root / f'{name}.json').read_text())
    for entry in data['benchmarks']:
        assert all(len(samples) == data['arguments']['runs'] for samples in entry['samples'].values())
        validation['measured_samples'] += sum(len(samples) for samples in entry['samples'].values())
        if 'http' in name:
            for variant, samples in entry['samples'].items():
                for sample in samples:
                    validation['http_requests'] += sample['requests']
                    route = entry['workload']
                    validation['http_body_hashes'].setdefault(route, sample['body_sha256'])
                    assert validation['http_body_hashes'][route] == sample['body_sha256']
                    assert sample['runtime']['opcache']['opcache_enabled']
                    assert not sample['runtime']['opcache']['jit']['on']
    if 'http' in name:
        for log in (root / f'{name}.work').glob('*.log'):
            if 'worker' in log.name and log.name.endswith('workers.log'):
                continue
            assert not re.search(r'PHP (Fatal|Warning)|panic:|segmentation fault', log.read_text(), re.I), str(log)
            validation['http_server_logs'] += 1
assert validation['measured_samples'] == 2408
for run in json.loads((root / 'correctness.json').read_text())['runs']:
    assert run['exit_code'] == 0
    counts = {}
    for line in run['results'].splitlines():
        key = line.split()[0]
        counts[key] = counts.get(key, 0) + 1
    assert counts == {'PASSED': 432, 'SKIPPED': 1}, counts
    validation['correctness_runs'].append({'variant': run['variant'], 'outcomes': counts})
(root / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
(out / f'{prefix}validation.json.gz').write_bytes(gzip.compress((root / 'validation.json').read_bytes(), mtime=0))
print(json.dumps({k: v for k, v in validation.items() if k != 'artifacts'}, indent=2))
