import json,pathlib,subprocess,time
root=pathlib.Path('/tmp/php86-flags-20260922')
while True:
 try:
  combined=json.loads((root/'combined-build/builds.json').read_text())
  smoke=json.loads((root/'phpstan-worker-smoke.json').read_text())
  if len(combined['builds'])==1 and smoke.get('finished_utc'): break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
base=json.loads((root/'builds.json').read_text())
assert base['source_commit']==combined['source_commit'] and base['compiler']==combined['compiler']
base['builds'].update(combined['builds']);base['flag_profiles']+=combined['profiles']
(root/'final-builds.json').write_text(json.dumps(base,indent=2)+'\n')
variants=['hybrid-tuned','tailcall-tuned','tailcall-omitfp','tailcall-medium-omitfp']
common=['--variants',*variants]
commands=[]
for sapi,seed in [('cli',8630),('libphp',8631)]:
 commands.append(['python3','benchmarks/benchmark-matrix.py','/tmp/opencode/packages-vm-lto-src',str(root/'final-builds.json'),'--output',str(root/('final-'+sapi+'.json')),'--sapi',sapi,'--runs','8','--warmups','2','--target-seconds','.2','--modes','on','--seed',str(seed),*common])
commands += [
 ['python3','benchmarks/benchmark-applications.py',str(root/'final-builds.json'),'phpstan','--demo','/tmp/php86-symfony-demo-20260922','--output',str(root/'final-phpstan.json'),'--runs','12','--warmups','2','--seed','8632',*common],
 ['python3','benchmarks/benchmark-applications.py',str(root/'final-builds.json'),'phpbench','--pts','/tmp/php86-app-benchmarks-20260922/pts','--output',str(root/'final-phpbench.json'),'--runs','6','--warmups','1','--seed','8633',*common]
]
http=['python3','benchmarks/benchmark-frankenphp.py',str(root/'final-builds.json'),'--frankenphp','/tmp/php86-frankenphp-20260922/frankenphp','--demo','/tmp/php86-symfony-demo-20260922','--wrk','/tmp/php-worker-jit/routes-v3/wrk-4.2.0-source/wrk','--duration','4','--warmup','1',*common]
commands.append(http+['--output',str(root/'final-http-1core.json'),'--runs','8','--seed','8634'])
commands.append(http+['--output',str(root/'final-http-4core.json'),'--runs','4','--seed','8635','--server-cpus','4,6,8,10','--php-threads','4','--connections','8','--client-threads','2'])
(root/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for cmd in commands:
 print('START',cmd,flush=True)
 subprocess.run(cmd,check=True,cwd='/home/m/packages')
print('FINAL BENCHMARKS COMPLETE',flush=True)
