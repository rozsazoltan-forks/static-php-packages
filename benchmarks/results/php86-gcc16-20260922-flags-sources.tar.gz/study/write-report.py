import json
from pathlib import Path
import statistics

root = Path('/tmp/php86-flags-20260922')
repo = Path('/home/m/packages/benchmarks')
analysis = json.loads((root / 'analysis.json').read_text())
sections = json.loads((root / 'build-sections.json').read_text())
variants = ['hybrid-tuned', 'tailcall-tuned', 'tailcall-omitfp', 'tailcall-medium-omitfp']
names = ['Hybrid', 'Current tailcall', 'Tailcall + omit FP', 'Medium + omit FP']
lines = []

def add(text):
    lines.extend([text.strip(), ''])

def table(headers, rows):
    add('| ' + ' | '.join(headers) + ' |\n| ' + ' | '.join(['---'] + ['---:'] * (len(headers) - 1)) + ' |\n' +
        '\n'.join('| ' + ' | '.join(str(value) for value in row) + ' |' for row in rows))

def effect(c):
    low, high = c['paired_bootstrap_95ci_percent']
    return f"{c['elapsed_change_percent']:+.1f}% [{low:+.1f}, {high:+.1f}]"

add('''# PHP 8.6 GCC: FrankenPHP, application benchmarks and tailcall compiler flags

**Every benchmark in this study uses OPcache, its normal optimizer and LTO; JIT is disabled.**

Tailcall's advantage does carry through to Symfony served by FrankenPHP. On one core, current tailcall improves worker throughput by **6.6% on the blog and 3.0% on the post**, with both 95% intervals above zero. Classic-mode gains on one core are approximately 2%, with intervals that include zero. Application behavior differs from the call-heavy Fibonacci microbenchmark.

Among the tested profiles, retaining the current inlining limits and 64-byte alignment is a sound general baseline. Adding `-fomit-frame-pointer` improves PHPStan and PHPBench and removes most of the Fibonacci regression. Medium inlining plus omitted frame pointers is a competitive, smaller alternative for HTTP, with mixed component results. There is no single flag set that wins every workload.

The study includes nine tailcall profiles and one matching hybrid reference, all built from the same PHP snapshot with the same extensions. Production frame-pointer policy is unchanged.''')

add('## Symfony Demo served by FrankenPHP')
add('Medians are requests per second, higher is better. “Omit FP” changes native C frame-pointer generation. “Medium” additionally lowers the inlining budgets; definitions follow below.')
http_rows = []
ci_rows = []
latency_rows = []
for dataset, cores in [('final-http-1core', '1 core'), ('final-http-4core', '4 cores')]:
    for row in analysis[dataset]:
        label = cores + ', ' + row['label']
        http_rows.append([label] + [f"{row['rps'][v]:.2f}" for v in variants])
        ci_rows.append([label] + [effect(c) for c in row['rps_hybrid_comparisons']])
        latency_rows.append([label] + [f"{row['p50_ms'][v]:.2f} / {row['p99_ms'][v]:.2f}" for v in variants])
table(['Mode / page'] + names, http_rows)
add('Throughput change relative to hybrid, with 95% paired bootstrap intervals. Positive is faster:')
table(['Mode / page'] + names[1:], ci_rows)
add('![Application throughput estimates and confidence intervals](results/php86-gcc16-20260922-flags-confirmation.png)')
add('Median of each run’s p50 / p99 latency, milliseconds, under the fixed concurrency used above:')
table(['Mode / page'] + names, latency_rows)
add('The comparison between VM variants is paired within a mode. Classic versus worker is a separate execution-model comparison: workers retain the application between requests and avoid repeated bootstrap. Do not attribute that much larger mode difference to the tailcall VM. Four-core results have fewer repetitions; use their intervals when assessing small differences.')

add('## PHPStan and official Phoronix PHPBench')
stan = analysis['final-phpstan'][0]
pts = analysis['final-phpbench'][0]
table(['Metric'] + names, [
    ['PHPStan full analysis, seconds'] + [f"{stan['median_seconds_per_unit'][v]:.3f}" for v in variants],
    ['PHPBench official score'] + [f"{pts['scores'][v]:,.0f}" for v in variants],
    ['PHPBench implied timed duration, seconds'] + [f"{pts['median_seconds_per_unit'][v]:.3f}" for v in variants]])
table(['Change versus hybrid'] + names[1:], [
    ['PHPStan elapsed time; negative is faster'] + [effect(c) for c in stan['hybrid_comparisons']],
    ['PHPBench score; positive is faster'] + [effect(c) for c in pts['score_hybrid_comparisons']]])
table(['Change versus current tailcall', 'Current budgets + omit FP', 'Medium budgets + omit FP'], [
    ['PHPStan elapsed time'] + [effect(c) for c in stan['tailcall_comparisons']],
    ['PHPBench score'] + [effect(c) for c in pts['score_tailcall_comparisons']]])
add('All 48 measured PHPStan analyses return zero errors, and all 96 measured parent/worker OPcache probes pass. All 24 official PHPBench invocations complete all 56 subtests. PHPBench is still a collection of interpreter microbenchmarks; the HTTP results above establish the framework behavior directly.')
subtests = json.loads((root / 'phpbench-subtests.json').read_text())['subtests']
selected = ['test_while', 'test_do_while', 'test_switch', 'test_ordered_functions',
            'test_unordered_functions', 'test_ordered_functions_references', 'test_rand']
by_name = {row['test']: row for row in subtests}
add('Representative PHPBench subtests, elapsed-time change versus hybrid. The full 56-subtest analysis is linked below. Aggregate gains coexist with individual regressions; these exploratory intervals have no multiple-comparison correction.')
table(['Subtest'] + names[1:], [[name] + [effect(c) for c in by_name[name]['comparisons']] for name in selected])

add('## Which flags performed best?')
add('''Keep LTO enabled for PHP 8.6. The current general-purpose tailcall baseline remains:

```text
-O3 -flto -falign-functions=64
--param=inline-unit-growth=200
--param=ipa-cp-unit-growth=100
--param=large-function-growth=1000
--param=max-inline-insns-auto=500
--param=max-inline-insns-single=1000
```

For a build prioritizing performance over frame-pointer-based native profiling, the strongest broadly useful additional candidate is **`-fomit-frame-pointer`**. It must override the existing `-fno-omit-frame-pointer` at compilation and survive the LTO link. PHPStan improves by about 4.4% relative to current tailcall, PHPBench score by about 2.5%, and Fibonacci time by about 6%. HTTP gains from this change alone are mixed. Keep frame pointers when their native profiling/debugging benefits matter; the performance flag is not a correctness requirement.

The **medium + omit-FP** alternative uses `100 / 100 / 500 / 250 / 500` in the same parameter order. It reduces shared-library executable `.text` from 22.18 MiB to 15.54 MiB relative to current budgets + omit-FP, approximately 30%. Its HTTP results make it worth considering for a web-focused build. It does not consistently beat current budgets + omit-FP in PHPStan, PHPBench or the component matrix, and its CLI fiber result is worse.

Increasing the budgets beyond the current values is not supported by this screen. The extreme profile grows `.text` to 33.99 MiB without a broad application gain. `-falign-functions=128` and `-mtune=znver3` also have no established broad advantage. Alignment 32 produces a repeatable, large Mandel regression on this host; retain 64 among the tested choices. `-mtune=znver3` preserved `-march=x86-64-v3`, so its result concerns scheduling, not an expanded instruction set.''')

table(['Profile', 'Inline budgets: unit / IPA / large / auto / single', 'Alignment', 'Frame pointers', 'libphp .text MiB'], [
    ['GCC defaults', '40 / 10 / 100 / 30 / 200', '64', 'retained', f"{sections['tailcall-default']['libphp_sections']['.text']/1048576:.2f}"],
    ['Medium', '100 / 100 / 500 / 250 / 500', '64', 'retained', f"{sections['tailcall-medium']['libphp_sections']['.text']/1048576:.2f}"],
    ['Current', '200 / 100 / 1000 / 500 / 1000', '64', 'retained', f"{sections['tailcall-tuned']['libphp_sections']['.text']/1048576:.2f}"],
    ['Extreme', '400 / 200 / 2000 / 1000 / 2000', '64', 'retained', f"{sections['tailcall-extreme']['libphp_sections']['.text']/1048576:.2f}"],
    ['Current + omit FP', '200 / 100 / 1000 / 500 / 1000', '64', 'omitted', f"{sections['tailcall-omitfp']['libphp_sections']['.text']/1048576:.2f}"],
    ['Medium + omit FP', '100 / 100 / 500 / 250 / 500', '64', 'omitted', f"{sections['tailcall-medium-omitfp']['libphp_sections']['.text']/1048576:.2f}"],
    ['Current + align32', 'current', '32', 'retained', f"{sections['tailcall-align32']['libphp_sections']['.text']/1048576:.2f}"],
    ['Current + align128', 'current', '128', 'retained', f"{sections['tailcall-align128']['libphp_sections']['.text']/1048576:.2f}"],
    ['Current + tune Zen 3', 'current', '64', 'retained', f"{sections['tailcall-znver3']['libphp_sections']['.text']/1048576:.2f}"]])
add('These sizes are the executable `.text` section, excluding read-only tables, unwind data, debug information and other ELF sections. The screen changes parameter groups, so it cannot identify the optimal independent value of each of the five interacting inlining limits.')
add('![Exploratory compiler flag screen](results/php86-gcc16-20260922-flags-screen.png)')
add('The screen compares each candidate to current tailcall flags. Default inlining is 24.4% slower on fibers and 7.2% slower on strings/JSON, while some other workloads improve. Medium budgets preserve much more of the benefit. Larger budgets trade code footprint against optimization opportunities; neither “more inlining is always faster” nor “LTO does nothing at defaults” describes these results.')

add('## All earlier micro/component workloads, rerun')
add('Each cell gives elapsed-time change versus the matching hybrid build and its 95% interval; **negative is faster**. Absolute per-workload medians and every sample are in the accompanying raw/derived data. Do not average these overlapping synthetic workloads into an application score.')
for dataset, heading in [('final-cli', 'Standalone CLI'), ('final-libphp', 'Shared libphp')]:
    add('### ' + heading)
    table(['Workload'] + names[1:], [[row['label']] + [effect(c) for c in row['hybrid_comparisons']]
                                   for row in analysis[dataset]])
add('The CLI `ary3` hybrid result is noisy and substantially slower than shared libphp; this layout-sensitive outlier also appeared in the earlier study. The new CLI `micro_bench.php` interval is wide and does not establish a current-tailcall gain, while shared libphp does. All samples remain included.')

add('## Fibonacci and the alignment regression')
add('''Fibonacci now takes 9.0% more CLI time with current tailcall than hybrid. Omitting frame pointers reduces that gap to 2.5%; shared libphp drops from 7.2% to about 1.3%. The median does not become universally faster than hybrid.

`fibo(30)` makes 2,692,537 tiny recursive calls. Native tailcall opcode dispatch does not eliminate this PHP recursion. It stresses user-call entry and return handling disproportionately, whereas Symfony, Twig and PHPStan execute a much wider opcode mix. Raising the C inlining limits alone did not cure this workload in the screen.

Disassembly of the actual shared libraries shows the current tailcall `DO_UCALL` handler executing `push %rbp; mov %rsp,%rbp` and restoring `%rbp` before its dispatch jump. The omit-FP build replaces this frame setup/restoration with stack alignment adjustments. Return handlers change too. The option also changes register allocation and code layout; the measured effect belongs to the whole compiled profile, not to one isolated instruction.''')
for sapi in ['cli', 'libphp']:
    filename = 'final-fibo-perf-cli-paired.json' if sapi == 'cli' else 'final-fibo-perf-libphp.json'
    perf = json.loads((root / filename).read_text())
    counters = {m['variant']: m['counters'] for m in perf['measurements']}
    add('### Fibonacci hardware counters: ' + ('CLI' if sapi == 'cli' else 'shared libphp'))
    table(['Counter change versus hybrid'] + names[1:], [
        [event] + [f"{100*(counters[v][event]/counters[variants[0]][event]-1):+.1f}%" for v in variants[1:]]
        for event in ['cycles:u', 'instructions:u', 'branches:u', 'branch-misses:u']])
perf = json.loads((root / 'align32-mandel-perf.json').read_text())
counters = {m['variant']: m['counters'] for m in perf['measurements']}
table(['Mandel: alignment 32 versus 64', 'Counter change'], [[event,
       f"{100*(counters['tailcall-align32'][event]/counters['tailcall-tuned'][event]-1):+.1f}%"]
       for event in ['cycles:u', 'instructions:u', 'branches:u', 'branch-misses:u']])
add('Alignment 32 leaves Mandel’s retired instruction and branch counts essentially unchanged, but branch misses rise from 0.68 million to 546.75 million, approximately 800 times as many; cycles rise about 160%. This is consistent with a severe code-layout/branch-prediction problem in this binary on Zen 3, rather than extra PHP work. It does not establish that 32-byte alignment is inherently slower on every CPU.')
add('Hardware counters cover the whole process, including setup and four internal warmups, using ten times the calibrated iteration count. CLI Fibonacci uses medians from eight balanced interleaved blocks. An earlier five-repeat sequential CLI pass contained two slow samples that inflated mean cycle counts; it is retained in the raw archive and not used for the table. Shared-library Fibonacci and Mandel use five-repeat diagnostics. These counters are separate from the primary timing matrix and are not application speed estimates. Exact counter values, event running percentages and repeat variation are retained in the perf output.')

add((root / 'report-method.md').read_text())
add('## Correctness and artifacts')
correctness = json.loads((root / 'correctness.json').read_text())
test_rows = []
for run in correctness['runs']:
    counts = {}
    for line in run['results'].splitlines():
        state = line.split()[0]
        counts[state] = counts.get(state, 0) + 1
    test_rows.append([run['variant'], run['exit_code'], ', '.join(f'{k}: {v}' for k, v in sorted(counts.items()))])
table(['Shared-library correctness run', 'Exit status', 'PHPT outcomes'], test_rows)
add('Each configuration passes 432 upstream tests and skips one requiring the unbuilt `zend_test` extension, with no failures or warnings. The selected closures, generators and fibers tests run after timing, with OPcache enabled in the controller, parallel workers and tested processes. Tests that explicitly manipulate OPcache settings are excluded. This is focused validation of the affected execution paths, not the entire PHP test suite.')
add('''The artifacts are local; no results were uploaded or published.

- [All build flags, hashes, compiler defaults and LTO evidence](results/php86-gcc16-20260922-flags-builds.json.gz)
- [FrankenPHP build provenance](results/php86-gcc16-20260922-flags-frankenphp-build.json.gz)
- [Screen: all CLI/component samples](results/php86-gcc16-20260922-flags-screen-cli.json.gz), [PHPStan](results/php86-gcc16-20260922-flags-screen-phpstan.json.gz), [Symfony worker](results/php86-gcc16-20260922-flags-screen-http.json.gz)
- [Final CLI samples](results/php86-gcc16-20260922-flags-final-cli.json.gz), [shared libphp samples](results/php86-gcc16-20260922-flags-final-libphp.json.gz)
- [Final PHPStan, including every worker probe](results/php86-gcc16-20260922-flags-final-phpstan.json.gz)
- [Final PTS scores, XML and all 56 subtest logs](results/php86-gcc16-20260922-flags-final-phpbench.json.gz)
- [FrankenPHP one-core samples and configurations](results/php86-gcc16-20260922-flags-final-http-1core.json.gz), [four-core samples](results/php86-gcc16-20260922-flags-final-http-4core.json.gz)
- [Derived comparisons and intervals](results/php86-gcc16-20260922-flags-analysis.json.gz), [all PHPBench subtest comparisons](results/php86-gcc16-20260922-flags-phpbench-subtests.json.gz)
- [Interleaved Fibonacci CLI counters](results/php86-gcc16-20260922-flags-final-fibo-perf-cli-paired.json.gz), [earlier sequential CLI counters](results/php86-gcc16-20260922-flags-final-fibo-perf-cli.json.gz), [shared-library counters](results/php86-gcc16-20260922-flags-final-fibo-perf-libphp.json.gz), [Mandel alignment counters](results/php86-gcc16-20260922-flags-align32-mandel-perf.json.gz)
- [Correctness logs](results/php86-gcc16-20260922-flags-correctness.json.gz), [OPcache status investigation](results/php86-gcc16-20260922-flags-opcache-status-note.json.gz)
- [Exact commands](results/php86-gcc16-20260922-flags-commands.json.gz), [dependencies](results/php86-gcc16-20260922-flags-dependencies.json.gz), [ELF section sizes](results/php86-gcc16-20260922-flags-build-sections.json.gz), [source snapshots and assembly](results/php86-gcc16-20260922-flags-sources.tar.gz)
- [Artifact hashes and validation summary](results/php86-gcc16-20260922-flags-validation.json.gz): 2,408 measured samples, 233,324 checked HTTP responses and 128 server logs with no PHP warnings, fatals or crashes.

The [earlier VM report](php86-gcc-inlining.md) and [earlier application report](php86-application-benchmarks.md) remain available; this study adds actual HTTP serving and independently confirms the flag candidates.

## Reproduction

Use a clean checkout of the pinned PHP source with `configure` generated. Build the reference pair, then the experimental profiles:

```sh
python3 benchmarks/build-vms.py /path/to/php-src /tmp/php86-reference \\
    --variants hybrid-tuned tailcall-tuned --application-extensions --jobs 16
python3 benchmarks/build-vms.py /path/to/php-src /tmp/php86-candidates \\
    --profiles benchmarks/php86-tailcall-profiles.json --application-extensions --jobs 16
```

Merge the two `builds` dictionaries into one metadata JSON while preserving their common source/compiler metadata. The exact command archive records all measured invocations and seeds. [benchmark-frankenphp.py](benchmark-frankenphp.py) accepts that metadata, the matching dynamic FrankenPHP executable, the prepared Symfony Demo directory and wrk:

```sh
python3 benchmarks/benchmark-frankenphp.py /tmp/php86-builds.json \\
    --frankenphp /path/to/frankenphp --demo /path/to/symfony-demo --wrk /path/to/wrk \\
    --variants hybrid-tuned tailcall-tuned tailcall-omitfp tailcall-medium-omitfp \\
    --runs 8 --duration 4 --warmup 1 --output /tmp/php86-http.json
```

For the four-core check add `--server-cpus 4,6,8,10 --php-threads 4 --connections 8 --client-threads 2` and use a new output path. Prepare the pinned app's production assets/container and the recorded logging override first. Build FrankenPHP following its [official compilation guidance](https://frankenphp.dev/docs/compile/), using the exact source, Go build flags and RUNPATH recorded in the build artifact. The general library must have the same PHP ABI as every candidate.

[benchmark-matrix.py](benchmark-matrix.py), [benchmark-applications.py](benchmark-applications.py) and [perf-matrix.py](perf-matrix.py) reproduce the other measurements. All benchmark commands default to OPcache enabled. PHPStan uses a dedicated INI so its spawned worker inherits the same setting. Replot the results using [plot-flag-screen.py](plot-flag-screen.py) and [plot-flag-confirmation.py](plot-flag-confirmation.py).''')
(repo / 'php86-frankenphp-flags.md').write_text('\n'.join(lines))
print(repo / 'php86-frankenphp-flags.md')
