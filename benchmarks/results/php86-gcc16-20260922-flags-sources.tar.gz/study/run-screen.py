import json,pathlib,subprocess,time
root=pathlib.Path('/tmp/php86-flags-20260922')
while True:
 try: extra=json.loads((root/'builds/builds.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError): extra={'builds':{}}
 if len(extra['builds'])==7: break
 time.sleep(5)
base=json.loads(pathlib.Path('/tmp/php86-app-builds-20260922/builds.json').read_text())
assert base['source_commit']==extra['source_commit'] and base['compiler']==extra['compiler']
base['builds'].update(extra['builds']);base['flag_profiles']=extra['profiles']
(root/'builds.json').write_text(json.dumps(base,indent=2)+'\n')
variants=['tailcall-tuned']+list(extra['builds'])
common=['--variants',*variants]
commands=[
 ['python3','benchmarks/benchmark-matrix.py','/tmp/opencode/packages-vm-lto-src',str(root/'builds.json'),'--output',str(root/'screen-cli.json'),'--runs','8','--warmups','2','--target-seconds','.15','--modes','on',*common],
 ['python3','benchmarks/benchmark-applications.py',str(root/'builds.json'),'phpstan','--demo','/tmp/php86-symfony-demo-20260922','--output',str(root/'screen-phpstan.json'),'--runs','4','--warmups','1',*common],
 ['python3','benchmarks/benchmark-frankenphp.py',str(root/'builds.json'),'--frankenphp','/tmp/php86-frankenphp-20260922/frankenphp','--demo','/tmp/php86-symfony-demo-20260922','--wrk','/tmp/php-worker-jit/routes-v3/wrk-4.2.0-source/wrk','--output',str(root/'screen-http.json'),'--modes','worker','--runs','4','--duration','3','--warmup','1',*common]
]
(root/'screen-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for cmd in commands:
 print('START',cmd,flush=True)
 subprocess.run(cmd,check=True,cwd='/home/m/packages')
print('SCREEN COMPLETE',flush=True)
