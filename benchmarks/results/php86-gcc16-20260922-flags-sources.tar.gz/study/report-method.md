## What was measured

All new measurements use **OPcache and its normal optimizer enabled, JIT disabled, and LTO enabled**. No new disabled-OPcache control was run. Every build is ZTS, uses GCC 16.2.0, and comes from the same unmodified PHP 8.6.0-dev source, `aefec40ab2f4858bf2abf8cef707837d3e0315c8`.

The machine is a Ryzen 9 5950X running AlmaLinux 10.2 under WSL2. CLI and shared-library workloads are pinned to logical CPU 4. HTTP uses either CPU 4 or four separate physical cores represented by CPUs 4, 6, 8 and 10; load generation runs on CPUs 16 and 18. Compilation and setup finished before measured runs. Variants run sequentially in randomized, balanced blocks. No samples are discarded. This is a shared development host, not a frequency-locked bare-metal laboratory; the intervals retain the observed noise.

The initial screen contains 1,024 CLI samples, 32 PHPStan analyses and 64 Symfony worker samples. Independent confirmation contains 512 CLI samples, 512 shared-libphp samples, 48 PHPStan analyses, 24 complete official PHPBench runs and 192 HTTP samples. Warmups are excluded from these counts. The screen selected finalists; its many comparisons are exploratory. All reported 95% intervals use 5,000 paired bootstrap resamples of whole measurement blocks and are not corrected for multiple comparisons. Four-core HTTP has only four blocks per configuration and is a scaling check, with correspondingly limited precision.

### PHP and compiler controls

The builds have the same application extension set: Phar, zlib, mbstring, intl, XML/DOM, fileinfo, PDO SQLite, SQLite3, pcntl, posix, OpenSSL, ctype, filter, tokenizer, session and iconv, in addition to core extensions. Their common flags include `-O3 -march=x86-64-v3 -fno-plt -fno-semantic-interposition -fno-math-errno`, PIC, section splitting, `-fcf-protection`, stack-clash protection, `_FORTIFY_SOURCE=3`, RELRO/NOW and a non-executable stack. No candidate changes PHP source, removes these hardening flags, or enables fast-math. Frame-pointer candidates append `-fomit-frame-pointer` to override the common `-fno-omit-frame-pointer`; all others retain the latter and `-momit-leaf-frame-pointer`. Hybrid's LTO link reserves its VM global registers, `r14` and `r15`.

Compiler options are checked in both the actual shared-library link command and GCC's stored LTO object options. Libtool requires forwarding the inlining parameters and function alignment with `-Wc,` at the link step. Binary and library SHA256 hashes, configure/make arguments, compiler defaults and runtime identities accompany the data. The same five inlining parameters appear in the [user-supplied Dockerfile](https://github.com/henderkes/frankenphp-php86-docker/blob/main/Dockerfile). These are compiler growth and size budgets, not instructions to inline every eligible function; GCC's documented [optimization options](https://gcc.gnu.org/onlinedocs/gcc/Optimize-Options.html) explain the individual limits.

LTO is enabled even for the profile named `tailcall-default`: “default” means default inlining limits. LTO already performs interprocedural optimization at those defaults. This study tests the tradeoff from larger budgets; it does not measure an LTO-off configuration.

### Symfony through FrankenPHP

FrankenPHP is pinned to `9b824f225ea64dd09a52049d96d34ef926af96dd`, built with Go 1.27.0, and dynamically linked to the common PHP 8.6 ABI. One identical executable serves every VM/flag configuration. It has `RUNPATH` rather than an overriding `RPATH`, so `LD_LIBRARY_PATH` selects the intended library. Every server checks `/proc/PID/maps`, the mapped library's hash, the VM identifier, ZTS, SAPI and INI settings. Unused Brotli, watcher, Mercure and database-driver features are excluded by Go build tags; this benchmark has no response compression.

Symfony Demo is pinned to `8d2e2ef75c3e18df173d8bf2379a14abb58c4c31`, with its unchanged Composer lock: Symfony 8.1.0 and Twig 3.27.1. Both routes use its real bundled SQLite fixture database:

- Blog index: `/en/blog/`.
- Post: `/en/blog/posts/lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit`.

The production container and AssetMapper/Sass assets are built before timing. The app's existing `public/index.php` and Symfony runtime implement both classic and persistent worker modes. The only application configuration override raises production Monolog thresholds to `critical`, preventing repeated PHP 8.6 compatibility notices from turning the experiment into a logging benchmark. This override is recorded verbatim in the raw data. There is no full-response cache, no database writes, no TLS, and no worker request-count restart.

One-core runs use one PHP thread/worker, two concurrent connections and one wrk thread, with eight blocks per configuration. Four-core runs use four PHP threads/workers, eight connections and two wrk threads, with four blocks. `GOMAXPROCS` matches the server core count. Worker mode has an additional regular PHP thread for diagnostic probes. All services bind only to `127.0.0.1`; Caddy's admin API is disabled.

Each variant/block/mode starts a fresh server and runs both routes. Before each four-second measurement there is a one-second load warmup. Every response must be HTTP 200 and contain at least 5,000 bytes. Sampled full-page hashes must match after normalizing only explicit `Page rendered on` and `Fragment rendered on` HTML comments. Runtime probes record cached-script counts, OPcache hits/restarts, optimizer settings and worker startup identities. Raw wrk output, p50/p90/p99 latency, server CPU time, configuration and library mappings are retained. Reported latency values summarize the per-run percentiles; they are not pooled request percentiles. These are closed-loop saturated load tests, not measurements of a complete production traffic distribution.

### OPcache status caveat in this PHP snapshot

The unmodified PHP snapshot has a ZTS initialization problem in OPcache's memory-size INI callbacks: after global startup, new threads reject those updates and their per-thread directive fields remain zero. Consequently FrankenPHP's status can report negative `used_memory` and `NaN` wasted percentage. This occurs with both VMs and all candidates. The actual 256 MiB shared cache and 8 MiB interned-string allocation exist; scripts are cached, hits accumulate, optimizer bits are `0x7ffebfff`, and measured samples have no cache-full condition or restart. JIT is disabled in both regular threads and workers. The diagnostic preserves the anomaly by encoding nonfinite values as strings. No memory-utilization conclusion uses these broken fields. PHP source was kept identical throughout.

### Other workloads

All 16 earlier micro/component workloads were rerun through both the standalone CLI and a small launcher calling PHP's CLI entry point from shared libphp. Each variant has eight measured processes after two process warmups. Isolated workloads include four internal warmup calls and use calibrated iteration counts shared by all variants. Their timings exclude setup; upstream `bench.php` and `micro_bench.php` use whole-process time. Output checksums must agree and isolated workloads must report themselves cached. The shared launcher measures the library used by embedders, but does not add Go or HTTP overhead.

Component workloads use the repository's installed Twig 3.29.0 and Symfony YAML 7.4.18. Those dependencies were installed before this screen and confirmation began. They differ from the Symfony Demo HTTP dependencies, and the full application builds differ from the earlier reduced-extension builds. Compare variants within the new matrices; do not interpret differences in absolute timings across earlier reports as a VM change.

PHPStan 2.2.2 analyzes Symfony Demo's 49 project files with its upstream level-6 configuration, baseline and Doctrine/Symfony extensions. An isolated temporary directory is deleted before each run, so result/parser/container caches are cold while OS file caches remain warm. Its maximum process count is one, with the normal child worker retained. A dedicated INI and bootstrap verify OPcache enabled, JIT disabled, VM and binary **inside every measured parent and worker**. All 48 measured analyses return identical zero-error JSON, and all 96 process probes pass. Two small bootstrap log writes per analysis are included equally in all timings.

Phoronix Test Suite 10.8.4 runs the unchanged official `pts/phpbench-1.1.6` profile, PHPBench 0.8.1 patched2, with two million iterations and all 56 subtests. The archive SHA256 is `32503bd4ace0c8429493de864ca48bb16febed867e52b75f4369d7145f797718`. `PHP_BIN` selects the exact PHP 8.6 wrapper; system PHP runs only the PTS controller. OPcache is enabled and JIT disabled for both. Six measured complete-profile invocations per variant follow one warmup, interleaved using `FORCE_TIMES_TO_RUN=1`. The score is higher-is-better and equals `20,000,000 / sum(subtest seconds)`, rounded by PTS. Implied duration uses that reciprocal score, not controller wall time. Automatic sample dropping is disabled. The isolated PTS configuration disables network access, uploads, anonymous reporting and browser launch; native XML and every subtest log remain local. Its automatic distribution-compiler label is not the compiler used for these PHP binaries.

## Link-flag question

`SPC_CMD_VAR_PHP_MAKE_EXTRA_LDFLAGS_LIBPHP` is additive. SPC's `unix.php` constructs shared-library flags by concatenating the general configured flags, `SPC_CMD_VAR_PHP_MAKE_EXTRA_LDFLAGS`, and then `SPC_CMD_VAR_PHP_MAKE_EXTRA_LDFLAGS_LIBPHP`. The PHP optimization flags therefore belong in the general link flags and do not need to be duplicated in the libphp-specific variable. The latter can retain only `-Wl,-Bsymbolic-functions`. This study also verifies the resulting compiler command and LTO metadata rather than assuming that a make-variable value survived libtool.

## Scope

These are the best-supported choices among the tested candidates on this GCC/PHP snapshot and Zen 3 host. They are not a global optimum across CPUs, compilers, PHP versions, applications, PGO profiles or all possible flag combinations. Hardening and the existing instruction-set baseline remain fixed. The frame-pointer change is kept as a benchmark candidate; this study does not silently change the repository's production profiling policy.
