<?php
// Render the supported build matrix, including hybrid overrides and future versions.
require dirname(__DIR__) . '/vendor/autoload.php';
define('BASE_PATH', dirname(__DIR__));
define('SPP_TARGET', null);
function getSharedLibrarySuffix(): string { return '-zts-86'; }
function str_replace_first(string $search, string $replace, string $value): string
{
    return preg_replace('/' . preg_quote($search, '/') . '/', $replace, $value, 1);
}
function check(bool $ok, string $message): void
{
    if (!$ok) {
        throw new RuntimeException($message);
    }
}

$twig = new Twig\Environment(new Twig\Loader\FilesystemLoader(BASE_PATH . '/config/templates'));
$parameters = ['inline-unit-growth=200', 'ipa-cp-unit-growth=100', 'large-function-growth=1000',
               'max-inline-insns-auto=500', 'max-inline-insns-single=1000'];
$count = 0;
foreach (['8.5', '8.6', '8.10'] as $version) {
    $lto = version_compare($version, '8.6', '>=');
    foreach (['x86_64', 'aarch64'] as $arch) {
        $actual = yaml_parse(staticphp\util\TwigRenderer::renderCraftTemplate($version, $arch));
        check(str_contains($actual['extra-env']['SPC_CMD_VAR_PHP_MAKE_EXTRA_CFLAGS'], ' -flto') === $lto,
            'Renderer did not set version-dependent PHP LTO');
        foreach (['rpm' => ['7', '8', '9', '10'], 'deb' => ['13'], 'apk' => ['3.21']] as $type => $oses) {
            foreach ($oses as $os) {
                foreach ([null, 'native-native-gnu'] as $target) {
                    foreach ([false, true] as $tailcall) {
                        $env = yaml_parse(ltrim($twig->render('craft.yml.twig', [
                            'php_version' => $version, 'use_php_lto' => $lto, 'use_tailcall_vm' => $tailcall,
                            'allow_shared_ext_failure' => $lto, 'target' => $target, 'arch' => $arch,
                            'os' => $os, 'type' => $type, 'prefix' => 'php-zts', 'release_suffix' => 'zts-86',
                            'moduledir' => '/usr/lib/php-zts/modules', 'ci' => false,
                        ])))['extra-env'];
                        $gcc = $target === null;
                        $cflags = $env['SPC_CMD_VAR_PHP_MAKE_EXTRA_CFLAGS'];
                        $ldflags = $env['SPC_CMD_VAR_PHP_MAKE_EXTRA_LDFLAGS'];
                        foreach (['CFLAGS', 'CXXFLAGS', 'LDFLAGS'] as $kind) {
                            $flags = $env['SPC_DEFAULT_' . $kind];
                            check(!str_contains($flags, '--param=') && !str_contains($flags, '-falign-functions'),
                                'PHP tuning leaked into dependencies');
                            check(str_contains($flags, '-flto') === !$gcc, 'Dependency LTO changed');
                        }
                        check(str_contains($cflags, ' -flto') === (!$gcc || $lto), 'Incorrect compile LTO');
                        check(str_contains($ldflags, ' -flto') === (!$gcc || $lto), 'Incorrect link LTO');
                        foreach ($parameters as $parameter) {
                            check(str_contains($cflags, ' --param=' . $parameter) === ($gcc && $lto), 'Incorrect compile inlining');
                            check(str_contains($ldflags, ' -Wc,--param=' . $parameter) === ($gcc && $lto), 'Inlining not forwarded through libtool');
                        }
                        check(!str_contains($cflags, '-Wc,'), 'libtool link flag leaked into configure CFLAGS');
                        check(str_contains($ldflags, ' -Wc,-falign-functions=64') === ($gcc && $tailcall && $arch === 'x86_64'),
                            'Incorrect shared-library alignment');
                        check($env['SPC_CMD_VAR_PHP_MAKE_EXTRA_LDFLAGS_LIBPHP'] === '-Wl,-Bsymbolic-functions',
                            'Redundant or missing libphp flags');
                        $count++;
                    }
                }
            }
        }
    }
}
echo "$count build configurations passed (including PHP 8.6 hybrid LTO).\n";
