
/tmp/php86-app-builds-20260922/tailcall-tuned/.libs/libphp.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000001628800 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0>:
 1628800:	endbr64
 1628804:	push   %rbp
 1628805:	movslq 0x8(%r13),%rax
 1628809:	mov    0x10(%r12),%rdx
 162880e:	add    %r12,%rax
 1628811:	mov    %rsp,%rbp
 1628814:	test   %rdx,%rdx
 1628817:	je     1628840 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x40>
 1628819:	mov    (%rax),%rcx
 162881c:	mov    0x8(%rax),%eax
 162881f:	mov    %rcx,(%rdx)
 1628822:	mov    %eax,0x8(%rdx)
 1628825:	lea    0x13208f4(%rip),%rax        # 2949120 <call_leave_op.lto_priv.0>
 162882c:	mov    %rax,(%r12)
 1628830:	mov    %rax,%r13
 1628833:	pop    %rbp
 1628834:	jmp    1608e00 <zend_leave_helper_SPEC_TAILCALL.lto_priv.0>
 1628839:	nopl   0x0(%rax)
 1628840:	cmpb   $0x0,0x9(%rax)
 1628844:	je     1628825 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x25>
 1628846:	mov    (%rax),%rdi
 1628849:	subl   $0x1,(%rdi)
 162884c:	jne    1628825 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x25>
 162884e:	mov    0x4(%rdi),%eax
 1628851:	lea    0x13a8ea8(%rip),%rdx        # 29d1700 <zend_rc_dtor_func.lto_priv.0>
 1628858:	mov    %r13,(%r12)
 162885c:	and    $0xf,%eax
 162885f:	call   *(%rdx,%rax,8)
 1628862:	jmp    1628825 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x25>

Disassembly of section .remap_stub:

Disassembly of section .fini:
