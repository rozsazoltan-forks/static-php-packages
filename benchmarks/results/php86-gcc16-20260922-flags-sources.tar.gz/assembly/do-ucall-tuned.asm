
/tmp/php86-app-builds-20260922/tailcall-tuned/.libs/libphp.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000001561d00 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0>:
 1561d00:	endbr64
 1561d04:	push   %rbp
 1561d05:	mov    %rsi,%rax
 1561d08:	mov    %rsp,%rbp
 1561d0b:	sub    $0x20,%rsp
 1561d0f:	mov    0x8(%rdi),%rdx
 1561d13:	mov    0x18(%rdx),%rsi
 1561d17:	mov    0x2c(%rdx),%ecx
 1561d1a:	mov    %rax,(%rdi)
 1561d1d:	mov    0x30(%rdx),%rax
 1561d21:	mov    %rax,0x8(%rdi)
 1561d25:	mov    0x68(%rsi),%rax
 1561d29:	mov    %rdi,0x30(%rdx)
 1561d2d:	mov    %rax,(%rdx)
 1561d30:	movq   $0x0,0x8(%rdx)
 1561d38:	movq   $0x0,0x10(%rdx)
 1561d40:	cmp    %ecx,0x20(%rsi)
 1561d43:	jb     1561df0 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xf0>
 1561d49:	testb  $0x1,0x5(%rsi)
 1561d4d:	jne    1561d5b <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0x5b>
 1561d4f:	mov    %ecx,%edi
 1561d51:	shl    $0x5,%rdi
 1561d55:	add    %rdi,%rax
 1561d58:	mov    %rax,(%rdx)
 1561d5b:	mov    0x5c(%rsi),%edi
 1561d5e:	cmp    %edi,%ecx
 1561d60:	jae    1561db7 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xb7>
 1561d62:	sub    %ecx,%edi
 1561d64:	lea    0x5(%rcx),%eax
 1561d67:	cltq
 1561d69:	lea    -0x1(%rdi),%ecx
 1561d6c:	shl    $0x4,%rax
 1561d70:	add    $0x1,%rcx
 1561d74:	add    %rdx,%rax
 1561d77:	shl    $0x4,%rcx
 1561d7b:	lea    (%rax,%rcx,1),%rdi
 1561d7f:	and    $0x10,%ecx
 1561d82:	je     1561da0 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xa0>
 1561d84:	movl   $0x0,0x8(%rax)
 1561d8b:	add    $0x10,%rax
 1561d8f:	cmp    %rdi,%rax
 1561d92:	je     1561db7 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xb7>
 1561d94:	data16 cs nopw 0x0(%rax,%rax,1)
 1561d9f:	nop
 1561da0:	movl   $0x0,0x8(%rax)
 1561da7:	add    $0x20,%rax
 1561dab:	movl   $0x0,-0x8(%rax)
 1561db2:	cmp    %rdi,%rax
 1561db5:	jne    1561da0 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xa0>
 1561db7:	mov    0x148c68a(%rip),%rcx        # 29ee448 <_GLOBAL_OFFSET_TABLE_+0x1ab0>
 1561dbe:	mov    0x38(%rsi),%rax
 1561dc2:	mov    %fs:(%rcx),%rcx
 1561dc6:	test   $0x1,%al
 1561dc8:	je     1561dd2 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xd2>
 1561dca:	mov    -0x70(%rcx),%rsi
 1561dce:	mov    (%rsi,%rax,1),%rax
 1561dd2:	mov    %rax,0x40(%rdx)
 1561dd6:	mov    (%rdx),%rax
 1561dd9:	mov    %rdx,-0x9b0(%rcx)
 1561de0:	leave
 1561de1:	or     $0x1,%rax
 1561de5:	ret
 1561de6:	cs nopw 0x0(%rax,%rax,1)
 1561df0:	mov    %rdx,%rdi
 1561df3:	mov    %ecx,-0x14(%rbp)
 1561df6:	mov    %rsi,-0x10(%rbp)
 1561dfa:	mov    %rdx,-0x8(%rbp)
 1561dfe:	call   15556c0 <zend_copy_extra_args.lto_priv.0>
 1561e03:	mov    -0x8(%rbp),%rdx
 1561e07:	mov    -0x10(%rbp),%rsi
 1561e0b:	mov    -0x14(%rbp),%ecx
 1561e0e:	jmp    1561d5b <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0x5b>

Disassembly of section .remap_stub:

Disassembly of section .fini:
