
/tmp/php86-flags-20260922/builds/tailcall-omitfp/.libs/libphp.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000001616000 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0>:
 1616000:	endbr64
 1616004:	sub    $0x8,%rsp
 1616008:	mov    %r12,%rax
 161600b:	mov    0x8(%r12),%r12
 1616010:	mov    0x30(%r12),%rdx
 1616015:	mov    0x18(%r12),%rbx
 161601a:	mov    %r13,(%rax)
 161601d:	mov    %rdx,0x8(%rax)
 1616021:	movslq 0x10(%r13),%rdx
 1616025:	mov    %rax,0x30(%r12)
 161602a:	mov    0x2c(%r12),%r13d
 161602f:	add    %rax,%rdx
 1616032:	mov    0x68(%rbx),%rax
 1616036:	movq   $0x0,0x8(%r12)
 161603f:	mov    %rdx,0x10(%r12)
 1616044:	mov    %rax,(%r12)
 1616048:	cmp    %r13d,0x20(%rbx)
 161604c:	jb     1616120 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0x120>
 1616052:	testb  $0x1,0x5(%rbx)
 1616056:	jne    1616066 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0x66>
 1616058:	mov    %r13d,%edx
 161605b:	shl    $0x5,%rdx
 161605f:	add    %rdx,%rax
 1616062:	mov    %rax,(%r12)
 1616066:	mov    0x5c(%rbx),%edx
 1616069:	cmp    %edx,%r13d
 161606c:	jae    16160d7 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xd7>
 161606e:	sub    %r13d,%edx
 1616071:	lea    0x5(%r13),%eax
 1616075:	sub    $0x1,%edx
 1616078:	cltq
 161607a:	shl    $0x4,%rax
 161607e:	add    $0x1,%rdx
 1616082:	add    %r12,%rax
 1616085:	shl    $0x4,%rdx
 1616089:	lea    (%rax,%rdx,1),%rcx
 161608d:	and    $0x10,%edx
 1616090:	je     16160c0 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xc0>
 1616092:	movl   $0x0,0x8(%rax)
 1616099:	add    $0x10,%rax
 161609d:	cmp    %rax,%rcx
 16160a0:	je     16160d7 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xd7>
 16160a2:	data16 cs nopw 0x0(%rax,%rax,1)
 16160ad:	data16 cs nopw 0x0(%rax,%rax,1)
 16160b8:	nopl   0x0(%rax,%rax,1)
 16160c0:	movl   $0x0,0x8(%rax)
 16160c7:	add    $0x20,%rax
 16160cb:	movl   $0x0,-0x8(%rax)
 16160d2:	cmp    %rax,%rcx
 16160d5:	jne    16160c0 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xc0>
 16160d7:	mov    0x13e136a(%rip),%rdx        # 29f7448 <_GLOBAL_OFFSET_TABLE_+0x1ab0>
 16160de:	mov    0x38(%rbx),%rax
 16160e2:	mov    %fs:(%rdx),%rdx
 16160e6:	test   $0x1,%al
 16160e8:	je     16160f2 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xf2>
 16160ea:	mov    -0x70(%rdx),%rcx
 16160ee:	mov    (%rcx,%rax,1),%rax
 16160f2:	mov    %rax,0x40(%r12)
 16160f7:	mov    (%r12),%r13
 16160fb:	mov    %r12,-0x9b0(%rdx)
 1616102:	movzbl -0x972(%rdx),%eax
 1616109:	test   %al,%al
 161610b:	jne    3b4fab <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0.cold>
 1616111:	mov    0x0(%r13),%rax
 1616115:	add    $0x8,%rsp
 1616119:	jmp    *%rax
 161611b:	nopl   0x0(%rax,%rax,1)
 1616120:	mov    %r12,%rdi
 1616123:	call   1560b00 <zend_copy_extra_args.lto_priv.0>
 1616128:	jmp    1616066 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0x66>

Disassembly of section .remap_stub:

Disassembly of section .fini:
