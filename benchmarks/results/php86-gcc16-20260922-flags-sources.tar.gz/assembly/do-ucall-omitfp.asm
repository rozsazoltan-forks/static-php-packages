
/tmp/php86-flags-20260922/builds/tailcall-omitfp/.libs/libphp.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000156c7c0 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0>:
 156c7c0:	endbr64
 156c7c4:	sub    $0x28,%rsp
 156c7c8:	mov    0x8(%rdi),%rdx
 156c7cc:	mov    %rsi,%rax
 156c7cf:	mov    0x18(%rdx),%rsi
 156c7d3:	mov    0x2c(%rdx),%ecx
 156c7d6:	mov    %rax,(%rdi)
 156c7d9:	mov    0x30(%rdx),%rax
 156c7dd:	mov    %rax,0x8(%rdi)
 156c7e1:	mov    0x68(%rsi),%rax
 156c7e5:	mov    %rdi,0x30(%rdx)
 156c7e9:	mov    %rax,(%rdx)
 156c7ec:	movq   $0x0,0x8(%rdx)
 156c7f4:	movq   $0x0,0x10(%rdx)
 156c7fc:	cmp    %ecx,0x20(%rsi)
 156c7ff:	jb     156c8b0 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xf0>
 156c805:	testb  $0x1,0x5(%rsi)
 156c809:	jne    156c817 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0x57>
 156c80b:	mov    %ecx,%edi
 156c80d:	shl    $0x5,%rdi
 156c811:	add    %rdi,%rax
 156c814:	mov    %rax,(%rdx)
 156c817:	mov    0x5c(%rsi),%edi
 156c81a:	cmp    %edi,%ecx
 156c81c:	jae    156c877 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xb7>
 156c81e:	sub    %ecx,%edi
 156c820:	lea    0x5(%rcx),%eax
 156c823:	cltq
 156c825:	lea    -0x1(%rdi),%ecx
 156c828:	shl    $0x4,%rax
 156c82c:	add    $0x1,%rcx
 156c830:	add    %rdx,%rax
 156c833:	shl    $0x4,%rcx
 156c837:	lea    (%rax,%rcx,1),%rdi
 156c83b:	and    $0x10,%ecx
 156c83e:	je     156c860 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xa0>
 156c840:	movl   $0x0,0x8(%rax)
 156c847:	add    $0x10,%rax
 156c84b:	cmp    %rdi,%rax
 156c84e:	je     156c877 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xb7>
 156c850:	data16 cs nopw 0x0(%rax,%rax,1)
 156c85b:	nopl   0x0(%rax,%rax,1)
 156c860:	movl   $0x0,0x8(%rax)
 156c867:	add    $0x20,%rax
 156c86b:	movl   $0x0,-0x8(%rax)
 156c872:	cmp    %rdi,%rax
 156c875:	jne    156c860 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xa0>
 156c877:	mov    0x148abca(%rip),%rcx        # 29f7448 <_GLOBAL_OFFSET_TABLE_+0x1ab0>
 156c87e:	mov    0x38(%rsi),%rax
 156c882:	mov    %fs:(%rcx),%rcx
 156c886:	test   $0x1,%al
 156c888:	je     156c892 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0xd2>
 156c88a:	mov    -0x70(%rcx),%rsi
 156c88e:	mov    (%rsi,%rax,1),%rax
 156c892:	mov    %rax,0x40(%rdx)
 156c896:	mov    (%rdx),%rax
 156c899:	mov    %rdx,-0x9b0(%rcx)
 156c8a0:	add    $0x28,%rsp
 156c8a4:	or     $0x1,%rax
 156c8a8:	ret
 156c8a9:	nopl   0x0(%rax)
 156c8b0:	mov    %rdx,%rdi
 156c8b3:	mov    %ecx,0x1c(%rsp)
 156c8b7:	mov    %rsi,0x10(%rsp)
 156c8bc:	mov    %rdx,0x8(%rsp)
 156c8c1:	call   1560b00 <zend_copy_extra_args.lto_priv.0>
 156c8c6:	mov    0x8(%rsp),%rdx
 156c8cb:	mov    0x10(%rsp),%rsi
 156c8d0:	mov    0x1c(%rsp),%ecx
 156c8d4:	jmp    156c817 <ZEND_DO_UCALL_SPEC_RETVAL_UNUSED_HANDLER.lto_priv.0+0x57>

Disassembly of section .remap_stub:

Disassembly of section .fini:
