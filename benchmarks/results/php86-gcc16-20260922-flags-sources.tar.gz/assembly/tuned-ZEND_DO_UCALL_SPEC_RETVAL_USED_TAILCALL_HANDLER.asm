
/tmp/php86-app-builds-20260922/tailcall-tuned/.libs/libphp.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000015ff280 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0>:
 15ff280:	endbr64
 15ff284:	push   %rbp
 15ff285:	mov    %r12,%rax
 15ff288:	mov    0x8(%r12),%r12
 15ff28d:	mov    0x30(%r12),%rdx
 15ff292:	mov    0x18(%r12),%rbx
 15ff297:	mov    %r13,(%rax)
 15ff29a:	mov    %rsp,%rbp
 15ff29d:	mov    %rdx,0x8(%rax)
 15ff2a1:	movslq 0x10(%r13),%rdx
 15ff2a5:	mov    %rax,0x30(%r12)
 15ff2aa:	mov    0x2c(%r12),%r13d
 15ff2af:	add    %rax,%rdx
 15ff2b2:	mov    0x68(%rbx),%rax
 15ff2b6:	movq   $0x0,0x8(%r12)
 15ff2bf:	mov    %rdx,0x10(%r12)
 15ff2c4:	mov    %rax,(%r12)
 15ff2c8:	cmp    %r13d,0x20(%rbx)
 15ff2cc:	jb     15ff3a0 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0x120>
 15ff2d2:	testb  $0x1,0x5(%rbx)
 15ff2d6:	jne    15ff2e6 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0x66>
 15ff2d8:	mov    %r13d,%edx
 15ff2db:	shl    $0x5,%rdx
 15ff2df:	add    %rdx,%rax
 15ff2e2:	mov    %rax,(%r12)
 15ff2e6:	mov    0x5c(%rbx),%edx
 15ff2e9:	cmp    %edx,%r13d
 15ff2ec:	jae    15ff357 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xd7>
 15ff2ee:	sub    %r13d,%edx
 15ff2f1:	lea    0x5(%r13),%eax
 15ff2f5:	sub    $0x1,%edx
 15ff2f8:	cltq
 15ff2fa:	shl    $0x4,%rax
 15ff2fe:	add    $0x1,%rdx
 15ff302:	add    %r12,%rax
 15ff305:	shl    $0x4,%rdx
 15ff309:	lea    (%rax,%rdx,1),%rcx
 15ff30d:	and    $0x10,%edx
 15ff310:	je     15ff340 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xc0>
 15ff312:	movl   $0x0,0x8(%rax)
 15ff319:	add    $0x10,%rax
 15ff31d:	cmp    %rax,%rcx
 15ff320:	je     15ff357 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xd7>
 15ff322:	data16 cs nopw 0x0(%rax,%rax,1)
 15ff32d:	data16 cs nopw 0x0(%rax,%rax,1)
 15ff338:	nopl   0x0(%rax,%rax,1)
 15ff340:	movl   $0x0,0x8(%rax)
 15ff347:	add    $0x20,%rax
 15ff34b:	movl   $0x0,-0x8(%rax)
 15ff352:	cmp    %rax,%rcx
 15ff355:	jne    15ff340 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xc0>
 15ff357:	mov    0x13ef0ea(%rip),%rdx        # 29ee448 <_GLOBAL_OFFSET_TABLE_+0x1ab0>
 15ff35e:	mov    0x38(%rbx),%rax
 15ff362:	mov    %fs:(%rdx),%rdx
 15ff366:	test   $0x1,%al
 15ff368:	je     15ff372 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0xf2>
 15ff36a:	mov    -0x70(%rdx),%rcx
 15ff36e:	mov    (%rcx,%rax,1),%rax
 15ff372:	mov    %rax,0x40(%r12)
 15ff377:	mov    (%r12),%r13
 15ff37b:	mov    %r12,-0x9b0(%rdx)
 15ff382:	movzbl -0x972(%rdx),%eax
 15ff389:	test   %al,%al
 15ff38b:	jne    3b09ae <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0.cold>
 15ff391:	mov    0x0(%r13),%rax
 15ff395:	pop    %rbp
 15ff396:	jmp    *%rax
 15ff398:	nopl   0x0(%rax,%rax,1)
 15ff3a0:	mov    %r12,%rdi
 15ff3a3:	call   15556c0 <zend_copy_extra_args.lto_priv.0>
 15ff3a8:	jmp    15ff2e6 <ZEND_DO_UCALL_SPEC_RETVAL_USED_TAILCALL_HANDLER.lto_priv.0+0x66>

Disassembly of section .remap_stub:

Disassembly of section .fini:
