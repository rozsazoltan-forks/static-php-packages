
/tmp/php86-flags-20260922/builds/tailcall-omitfp/.libs/libphp.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000163b740 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0>:
 163b740:	endbr64
 163b744:	sub    $0x8,%rsp
 163b748:	movslq 0x8(%r13),%rax
 163b74c:	mov    0x10(%r12),%rdx
 163b751:	add    %r12,%rax
 163b754:	test   %rdx,%rdx
 163b757:	je     163b780 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x40>
 163b759:	mov    (%rax),%rcx
 163b75c:	mov    0x8(%rax),%eax
 163b75f:	mov    %rcx,(%rdx)
 163b762:	mov    %eax,0x8(%rdx)
 163b765:	lea    0x13243d4(%rip),%rax        # 295fb40 <call_leave_op.lto_priv.0>
 163b76c:	mov    %rax,(%r12)
 163b770:	mov    %rax,%r13
 163b773:	add    $0x8,%rsp
 163b777:	jmp    1619180 <zend_leave_helper_SPEC_TAILCALL.lto_priv.0>
 163b77c:	nopl   0x0(%rax)
 163b780:	cmpb   $0x0,0x9(%rax)
 163b784:	je     163b765 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x25>
 163b786:	mov    (%rax),%rdi
 163b789:	subl   $0x1,(%rdi)
 163b78c:	jne    163b765 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x25>
 163b78e:	mov    0x4(%rdi),%eax
 163b791:	lea    0x139ef68(%rip),%rdx        # 29da700 <zend_rc_dtor_func.lto_priv.0>
 163b798:	mov    %r13,(%r12)
 163b79c:	and    $0xf,%eax
 163b79f:	call   *(%rdx,%rax,8)
 163b7a2:	jmp    163b765 <ZEND_RETURN_SPEC_TMP_TAILCALL_HANDLER.lto_priv.0+0x25>

Disassembly of section .remap_stub:

Disassembly of section .fini:
